# D&D 5e Character Sheet, Inventory & Campaign Notes System

Welcome to the D&D 5e Character Sheet & Campaign Notes suite!

## 🚀 Quick Start
1. Open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari).
2. Create, customize, and manage your character stats, inventory items, equipment, hit points, and spell list!
3. Click **📓 D&D Notes** in the top navigation bar to open your Campaign Notes workspace (`dnd-notes.html`).

## 📁 File Structure
- `index.html` — Main Character Sheet, Inventory & Spell System interface
- `dnd-notes.html` — Full-featured D&D Campaign Notes workspace with category trees, drawing canvas, and sheets
- `spell-catalog.json` — Complete D&D 5e Spell Database containing 1,250+ spells with full details, damage, and filters
- `css/` — Stylesheets for UI layout and styling
- `js/` — Modular JavaScript application logic

## ✨ Features
- **Character Sheet & Stats**: Customizable stats, saving throws, skills, proficiencies, class & race editing.
- **BG3-Style Inventory**: Item slots (Head, Neck, Cloak, Chest, Hands, Ring, Main Hand, Off Hand, Boots), carry capacity, item rarities, active item effects & attunements.
- **1,250+ Spell Catalog**: Prepared spell list management, spell slot tracker, level/class/school filters, and instant spell lookup.
- **HP & Temp HP Tracker**: Quick damage, healing, and temporary HP shielding with live visual bar.
- **Features & Traits**: Class features, species traits, feats, and background & alignment manager.
- **Campaign Notes**: Session notes, NPC tracking, location maps, quest logs, export/import JSON backups, and background customization.
