
const STORAGE_KEY = 'hoard_inventory_v1';
let state = {
  STORAGE_KEY: 'dnd_character_sheet_v1',
  campaign: 'Party Inventory Ledger',
  characterName: 'Hero',
  characterClass: 'Bard',
  characterRace: 'Human',
  characterLevel: 1,
  background: 'Entertainer',
  backgroundFeature: 'By Popular Demand',
  alignment: 'Neutral Good',
  ideals: 'I bring joy and harmony wherever I travel.',
  bonds: 'My instrument is my most prized possession.',
  flaws: 'I can rarely resist a good tavern tale.',
  currency: { platinum: 0, gold: 15, electrum: 0, silver: 0, copper: 0 },
  capacity: 150,
  hp: { current: 10, max: 10, temp: 0 },
  stats: { str: 10, dex: 10, con: 10, int: 10, wis: 10, cha: 10 },
  saveProfs: { str: false, dex: true, con: false, int: false, wis: false, cha: true },
  skillProfs: { acrobatics: true, performance: true, persuasion: true },
  proficienciesText: 'Simple weapons, Hand crossbows, Longswords, Rapiers, Shortswords, Light armor',
  weaponProfs: { simple: true, martial: false, exotic: false },
  items: [],
  selectedId: null,
  deathSaves: { open: true, successes: [false, false, false], failures: [false, false, false] },
  attunements: { open: true, slots: [null, null, null] },
  spellSlots: {
    max: { 1: 2, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 },
    used: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 }
  },
  spellbook: {
    open: true, query: '', classFilter: '', levelFilter: '', schoolFilter: '', sortBy: 'level-asc',
    catalogLoaded: false, loading: false, error: '', catalog: [], list: [],
    maxPerLevel: { 0: 2, 1: 4, 2: 3, 3: 2, 4: 2, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1 }
  },
  features: [
    {
      id: 'f1',
      name: 'Bardic Inspiration',
      source: 'PHB, pg. 53',
      uses: 3,
      maxUses: 3,
      resetType: 'Long Rest',
      desc: 'Use a Bonus Action to inspire one creature within 60 feet.'
    }
  ],
  activeTab: 'inventory',
  theme: { customBg: '#121110', customAccent: '#eab308' }
};

const THEMES = {
  leather: { label:'Leather', void:'#100b08', panel:'#1c150f', panel2:'#251c14', panel3:'#2e2318', border:'#4a3a24', borderBright:'#8a6d3b', gold:'#c9a227', goldBright:'#e8cf7a', text:'#e9e0c8', textDim:'#a89876', textFaint:'#6e6248' },
  bloodmoon: { label:'Bloodmoon', void:'#150a0a', panel:'#241012', panel2:'#2e1416', panel3:'#3a1a1d', border:'#5a2020', borderBright:'#8f3535', gold:'#c9424a', goldBright:'#e8707a', text:'#ecdcd7', textDim:'#a98e89', textFaint:'#6e5a56' },
  arcane: { label:'Arcane', void:'#0a0d14', panel:'#141a26', panel2:'#1c2433', panel3:'#252e40', border:'#2e3a52', borderBright:'#4a6a9a', gold:'#7a9ad9', goldBright:'#a8c4ef', text:'#dbe6f2', textDim:'#8a9ab0', textFaint:'#5a6a80' },
  emerald: { label:'Emerald', void:'#0a120d', panel:'#131f17', panel2:'#1a2b20', panel3:'#22362a', border:'#2e4a38', borderBright:'#4a7a5a', gold:'#5fae6d', goldBright:'#8ed99c', text:'#dcecdf', textDim:'#8fae96', textFaint:'#5a725e' },
  parchment: { label:'Parchment', void:'#e8dfc5', panel:'#f3ecd6', panel2:'#eae0c2', panel3:'#e0d3ac', border:'#c4b184', borderBright:'#a8925a', gold:'#8a5a1e', goldBright:'#6e4415', text:'#2e2416', textDim:'#5a4a30', textFaint:'#8a7a5a' },
  custom: { label:'Custom' }
};

function hexToRgb(hex){
  const m = hex.replace('#','').match(/.{1,2}/g);
  return m ? m.map(h=>parseInt(h,16)) : [16,11,8];
}
function shade(hex, amt){
  const [r,g,b] = hexToRgb(hex);
  const f = c => Math.max(0, Math.min(255, Math.round(c + amt)));
  return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')';
}

function applyTheme(){
  const t = state.theme || { preset:'leather' };
  let p = THEMES[t.preset] || THEMES.leather;
  if(t.preset === 'custom'){
    const bg = t.customBg || '#100b08';
    const accent = t.customAccent || '#c9a227';
    p = {
      void: bg, panel: shade(bg, 14), panel2: shade(bg, 22), panel3: shade(bg, 30),
      border: shade(bg, 44), borderBright: shade(bg, 70),
      gold: accent, goldBright: shade(accent, 40),
      text: '#e9e0c8', textDim:'#a89876', textFaint:'#6e6248'
    };
  }
  const root = document.documentElement.style;
  root.setProperty('--void', p.void);
  root.setProperty('--panel', p.panel);
  root.setProperty('--panel-2', p.panel2);
  root.setProperty('--panel-3', p.panel3);
  root.setProperty('--border', p.border);
  root.setProperty('--border-bright', p.borderBright);
  root.setProperty('--gold', p.gold);
  root.setProperty('--gold-bright', p.goldBright);
  root.setProperty('--text', p.text);
  root.setProperty('--text-dim', p.textDim);
  root.setProperty('--text-faint', p.textFaint);
}

function renderThemeSwatches(){
  const box = document.getElementById('theme-swatches');
  if(!box) return;
  const t = state.theme || { preset:'leather' };
  box.innerHTML = Object.keys(THEMES).map(function(key){
    const p = THEMES[key];
    const isCustom = key === 'custom';
    const topColor = isCustom ? (t.customBg || '#100b08') : p.panel;
    const botColor = isCustom ? (t.customAccent || '#c9a227') : p.gold;
    return '<button class="swatch-btn' + (t.preset===key?' active':'') + '" title="' + p.label + '" onclick="pickTheme(\'' + key + '\')">' +
      '<span class="sw-half sw-top" style="background:' + topColor + '"></span>' +
      '<span class="sw-half sw-bottom" style="background:' + botColor + '"></span>' +
      '<span class="sw-label">' + (isCustom ? '✎' : '') + '</span>' +
    '</button>';
  }).join('');
  const customRow = document.getElementById('custom-theme-row');
  if(customRow) customRow.style.display = t.preset === 'custom' ? 'block' : 'none';
  if(t.preset === 'custom'){
    const cBg = document.getElementById('c-bg');
    const cAcc = document.getElementById('c-accent');
    if(cBg) cBg.value = t.customBg || '#100b08';
    if(cAcc) cAcc.value = t.customAccent || '#c9a227';
  }
}

function pickTheme(key){
  state.theme = state.theme || {};
  state.theme.preset = key;
  if(key === 'custom'){
    state.theme.customBg = state.theme.customBg || '#100b08';
    state.theme.customAccent = state.theme.customAccent || '#c9a227';
  }
  applyTheme();
  renderThemeSwatches();
  save();
}

function updateCustomTheme(){
  state.theme.preset = 'custom';
  const cBg = document.getElementById('c-bg');
  const cAcc = document.getElementById('c-accent');
  if(cBg) state.theme.customBg = cBg.value;
  if(cAcc) state.theme.customAccent = cAcc.value;
  applyTheme();
  renderThemeSwatches();
  save();
}

function load(){
  const raw = localStorage.getItem(STORAGE_KEY);
  if(raw){
    try{ state = Object.assign(state, JSON.parse(raw)); }catch(e){}
  }
  state.deathSaves = Object.assign({ open:true, successes:[false,false,false], failures:[false,false,false] }, state.deathSaves || {});
  state.deathSaves.successes = Array.isArray(state.deathSaves.successes) ? state.deathSaves.successes.slice(0,3).map(Boolean) : [false,false,false];
  while(state.deathSaves.successes.length < 3) state.deathSaves.successes.push(false);
  state.deathSaves.failures = Array.isArray(state.deathSaves.failures) ? state.deathSaves.failures.slice(0,3).map(Boolean) : [false,false,false];
  while(state.deathSaves.failures.length < 3) state.deathSaves.failures.push(false);
}
function save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }

function normalizeState(){
  const legacyGold = Number(state.gold || 0);
  state.currency = Object.assign({ platinum:0, gold:0, electrum:0, silver:0, copper:0 }, state.currency || {});
  if(!state.currency.gold && legacyGold){
    state.currency.gold = legacyGold;
  }
  delete state.gold;

  state.deathSaves = Object.assign({ open:true, successes:[false,false,false], failures:[false,false,false] }, state.deathSaves || {});
  state.deathSaves.successes = Array.isArray(state.deathSaves.successes) ? state.deathSaves.successes.slice(0,3).map(Boolean) : [false,false,false];
  while(state.deathSaves.successes.length < 3) state.deathSaves.successes.push(false);
  state.deathSaves.failures = Array.isArray(state.deathSaves.failures) ? state.deathSaves.failures.slice(0,3).map(Boolean) : [false,false,false];
  while(state.deathSaves.failures.length < 3) state.deathSaves.failures.push(false);

  state.attunements = Object.assign({ open:true, slots:[null,null,null] }, state.attunements || {});
  state.attunements.slots = Array.isArray(state.attunements.slots) ? state.attunements.slots.slice(0,3) : [null,null,null];
  while(state.attunements.slots.length < 3) state.attunements.slots.push(null);
  const attuneableIds = new Set((state.items || []).filter(function(i){ return i && i.attunementRequired; }).map(function(i){ return i.id; }));
  const seen = new Set();
  state.attunements.slots = state.attunements.slots.map(function(id){
    if(!id || !attuneableIds.has(id) || seen.has(id)) return null;
    seen.add(id);
    return id;
  });

  state.spellSlots = Object.assign({
    max: { 1:4, 2:3, 3:2, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0 },
    used: { 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0 }
  }, state.spellSlots || {});

  state.spellbook = Object.assign({
    open:true, query:'', classFilter:'', levelFilter:'', schoolFilter:'', sortBy:'level-asc',
    catalogLoaded:false, loading:false, error:'', catalog:[], list:[],
    maxPerLevel: { 0:3, 1:4, 2:3, 3:2, 4:2, 5:1, 6:1, 7:1, 8:1, 9:1 }
  }, state.spellbook || {});
  state.spellbook.maxPerLevel = Object.assign({ 0:3, 1:4, 2:3, 3:2, 4:2, 5:1, 6:1, 7:1, 8:1, 9:1 }, state.spellbook.maxPerLevel || {});
  state.spellbook.catalog = Array.isArray(state.spellbook.catalog) ? state.spellbook.catalog : [];
  state.spellbook.list = Array.isArray(state.spellbook.list) ? state.spellbook.list : [];
}

function attunedSlotIndex(itemId){
  return (state.attunements && state.attunements.slots) ? state.attunements.slots.indexOf(itemId) : -1;
}

function uid(){ return 'i' + Math.random().toString(36).slice(2,10); }

const SLOT_LABELS = {
  head:'Head', neck:'Neck', cloak:'Cloak', chest:'Chest', hands:'Hands',
  belt:'Belt', ring1:'Ring', ring2:'Ring', main:'Main Hand', off:'Off Hand', boots:'Boots'
};
const SLOT_ICONS = {
  head:'🪖', neck:'📿', cloak:'🧥', chest:'🛡', hands:'🧤',
  belt:'🎗', ring1:'💍', ring2:'💍', main:'🗡', off:'🛡', boots:'🥾'
};


function switchMainTab(tabName){
  if(!tabName) tabName = 'inventory';
  state.activeTab = tabName;
  const invView = document.getElementById('inventory-view-container');
  const spellView = document.getElementById('spellbook-view-container');
  const featuresView = document.getElementById('features-view-container');
  const btnInv = document.getElementById('tab-btn-inventory');
  const btnSpell = document.getElementById('tab-btn-spells');
  const btnFeatures = document.getElementById('tab-btn-features');

  if(invView) invView.style.display = (tabName === 'inventory') ? 'grid' : 'none';
  if(spellView) spellView.style.display = (tabName === 'spells') ? 'block' : 'none';
  if(featuresView) featuresView.style.display = (tabName === 'features') ? 'block' : 'none';

  if(btnInv) btnInv.classList.toggle('active', tabName === 'inventory');
  if(btnSpell) btnSpell.classList.toggle('active', tabName === 'spells');
  if(btnFeatures) btnFeatures.classList.toggle('active', tabName === 'features');

  if(tabName === 'spells'){
    state.spellbook.open = true;
    renderSpellbookMenu();
  } else if(tabName === 'features'){
    renderFeaturesView();
  }
  save();
}



function toggleActiveEffectsMenu(){
  state.activeEffectsOpen = state.activeEffectsOpen === undefined ? true : !state.activeEffectsOpen;
  save();
  renderActiveEffects();
}

function renderActiveEffects(){
  const menu = document.getElementById('active-effects-menu');
  const toggleBtn = document.getElementById('active-effects-toggle');
  const isOpen = state.activeEffectsOpen !== false;
  if(menu) menu.style.display = isOpen ? 'block' : 'none';
  if(toggleBtn) toggleBtn.textContent = isOpen ? 'Hide' : 'Show';

  const box = document.getElementById('active-effects-list');
  if(!box) return;
  const equippedItems = (state.items||[]).filter(i=>i.equipped);
  let html = '';
  equippedItems.forEach(i=>{
    (i.buffs||[]).forEach(b=>{
      html += '<div class="effect-tag"><span>▲</span><span><b>' + escapeHtml(b.name) + '</b>' + (b.desc ? ' — ' + escapeHtml(b.desc) : '') + '</span></div>';
    });
    (i.debuffs||[]).forEach(d=>{
      html += '<div class="effect-tag debuff"><span>▼</span><span><b>' + escapeHtml(d.name) + '</b>' + (d.desc ? ' — ' + escapeHtml(d.desc) : '') + '</span></div>';
    });
  });
  box.innerHTML = html || '<div class="hint">Equip items to see their effects here.</div>';
}


const DND_SKILLS = [
  { name: 'Acrobatics', stat: 'dex' },
  { name: 'Animal Handling', stat: 'wis' },
  { name: 'Arcana', stat: 'int' },
  { name: 'Athletics', stat: 'str' },
  { name: 'Deception', stat: 'cha' },
  { name: 'History', stat: 'int' },
  { name: 'Insight', stat: 'wis' },
  { name: 'Intimidation', stat: 'cha' },
  { name: 'Investigation', stat: 'int' },
  { name: 'Medicine', stat: 'wis' },
  { name: 'Nature', stat: 'int' },
  { name: 'Perception', stat: 'wis' },
  { name: 'Performance', stat: 'cha' },
  { name: 'Persuasion', stat: 'cha' },
  { name: 'Religion', stat: 'int' },
  { name: 'Sleight of Hand', stat: 'dex' },
  { name: 'Stealth', stat: 'dex' },
  { name: 'Survival', stat: 'wis' }
];

function getAbilityMod(score){
  return Math.floor((Number(score || 10) - 10) / 2);
}
function formatMod(mod){
  return mod >= 0 ? '+' + mod : String(mod);
}


function quickEditStat(key){
  if(!state.characterStats) return;
  const labels = {
    str: 'Strength (STR)', dex: 'Dexterity (DEX)', con: 'Constitution (CON)',
    int: 'Intelligence (INT)', wis: 'Wisdom (WIS)', cha: 'Charisma (CHA)',
    profBonus: 'Proficiency Bonus', speed: 'Speed (ft)', initBonus: 'Initiative Bonus', ac: 'Armor Class (AC)'
  };
  const current = state.characterStats[key] !== undefined ? state.characterStats[key] : (key==='speed'?25:(key==='ac'?10:(key==='profBonus'?2:10)));
  const val = prompt('Enter number for ' + (labels[key] || key) + ':', current);
  if(val !== null && val.trim() !== ''){
    const num = parseInt(val, 10);
    if(!isNaN(num)){
      state.characterStats[key] = num;
      save();
      renderCharacterStats();
    }
  }
}


function quickEditSkillBonus(skillName){
  if(!state.characterStats) return;
  state.characterStats.skillCustomBonuses = state.characterStats.skillCustomBonuses || {};
  const cs = state.characterStats;
  if(!cs.characterClass) cs.characterClass = 'Bard';
  if(!cs.species) cs.species = 'Half-Elf';
  if(!cs.level) cs.level = 5;

  
  const sk = DND_SKILLS.find(function(s){ return s.name === skillName; });
  const statMod = getAbilityMod(cs[sk ? sk.stat : 'str']);
  const profLevel = Number((cs.skillProfs && cs.skillProfs[skillName]) || 0);
  const currentCustom = Number(cs.skillCustomBonuses[skillName] || 0);
  const baseBonus = statMod + (profLevel * (cs.profBonus || 2));
  const currentTotal = baseBonus + currentCustom;

  const val = prompt('Set total bonus for ' + skillName + ' (Base is ' + formatMod(baseBonus) + '):', currentTotal);
  if(val !== null && val.trim() !== ''){
    const num = parseInt(val, 10);
    if(!isNaN(num)){
      cs.skillCustomBonuses[skillName] = num - baseBonus;
      save();
      renderCharacterStats();
    }
  }
}

function quickEditSaveBonus(statKey){
  if(!state.characterStats) return;
  state.characterStats.saveCustomBonuses = state.characterStats.saveCustomBonuses || {};
  const cs = state.characterStats;
  const isProf = !!(cs.saveProfs && cs.saveProfs[statKey]);
  const baseBonus = getAbilityMod(cs[statKey]) + (isProf ? (cs.profBonus||2) : 0);
  const currentCustom = Number(cs.saveCustomBonuses[statKey] || 0);
  const currentTotal = baseBonus + currentCustom;

  const val = prompt('Set total bonus for ' + statKey.toUpperCase() + ' Save (Base is ' + formatMod(baseBonus) + '):', currentTotal);
  if(val !== null && val.trim() !== ''){
    const num = parseInt(val, 10);
    if(!isNaN(num)){
      cs.saveCustomBonuses[statKey] = num - baseBonus;
      save();
      renderCharacterStats();
    }
  }
}

function autoCalcProfBonusFromLevel(){
  const lvl = parseInt(document.getElementById('st-level') ? document.getElementById('st-level').value : 5, 10) || 1;
  const pb = Math.floor((lvl - 1) / 4) + 2;
  const profInput = document.getElementById('st-prof');
  if(profInput) profInput.value = pb;
}

function renderCharacterStats(){
  if(!state.characterStats){
    state.characterStats = {
      str: 16, dex: 8, con: 14, int: 12, wis: 10, cha: 14,
      profBonus: 2, speed: 25, initBonus: 0, ac: 10,
      characterClass: 'Bard', species: 'Half-Elf', level: 5,
      armorProf: 'Light Armor, Medium Armor',
      weaponProf: 'Simple Weapons, Martial Weapons',
      toolProf: '',
      languages: 'Common, Elvish',
      saveNotes: '', senseNotes: '',
      saveProfs: {}, skillProfs: {}, saveCustomBonuses: {}, skillCustomBonuses: {}
    };
  }
  const cs = state.characterStats;
  if(!cs.characterClass) cs.characterClass = 'Bard';
  if(!cs.species) cs.species = 'Half-Elf';
  if(!cs.level) cs.level = 5;

  // Render Character Identity Badge in Left Panel
  const identityEl = document.getElementById('character-identity-badge');
  if(identityEl){
    identityEl.innerHTML = `<div style="background:rgba(0,0,0,0.3); border:1px solid var(--border-bright); border-radius:6px; padding:6px 10px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center; cursor:pointer;" onclick="openCharacterStatsModal()" title="Click to edit Class, Level & Species">
        <div>
          <div style="font-size:10px; text-transform:uppercase; color:var(--gold-bright); font-weight:bold;">Character Identity</div>
          <div style="font-size:13px; font-weight:bold; color:#fff;">Lvl ${cs.level} ${escapeHtml(cs.characterClass)}${cs.subclass ? ' (' + escapeHtml(cs.subclass) + ')' : ''}</div>
          <div style="font-size:11px; color:var(--text-dim);">${escapeHtml(cs.species)}${cs.subrace ? ' (' + escapeHtml(cs.subrace) + ')' : ''}</div>
        </div>
        <button class="btn ghost small" style="padding:2px 8px; font-size:11px;" onclick="event.stopPropagation(); openCharacterStatsModal();">⚙️ Edit</button>
      </div>`;
  }

  const subEl = document.getElementById('campaign-sub');
  if(subEl){
    const classStr = 'Lvl ' + cs.level + ' ' + cs.characterClass + (cs.subclass ? ' (' + cs.subclass + ')' : '') + ' · ' + cs.species + (cs.subrace ? ' (' + cs.subrace + ')' : '');
    subEl.textContent = (state.campaign || 'Party Inventory Ledger') + ' | ' + classStr;
  }

  // Ability Scores Grid
  const gridEl = document.getElementById('ability-scores-grid');
  if(gridEl){
    const abilities = [
      { key: 'str', label: 'STR' },
      { key: 'dex', label: 'DEX' },
      { key: 'con', label: 'CON' },
      { key: 'int', label: 'INT' },
      { key: 'wis', label: 'WIS' },
      { key: 'cha', label: 'CHA' }
    ];
    gridEl.innerHTML = abilities.map(function(ab){
      const score = Number(cs[ab.key] !== undefined ? cs[ab.key] : 10);
      const mod = getAbilityMod(score);
      return `<div class="ability-card" style="cursor:pointer;" title="Click to change ${ab.label} score to any number" onclick="quickEditStat('${ab.key}')">
          <div class="mod">${formatMod(mod)}</div>
          <div class="name">${ab.label}</div>
          <div class="score">${score}</div>
        </div>`;
    }).join('');
  }

  // Combat Stats Bar
  const combatBarEl = document.getElementById('combat-stats-bar');
  if(combatBarEl){
    const prof = cs.profBonus || 2;
    const speed = cs.speed || 25;
    const init = cs.initBonus || 0;
    const ac = cs.ac || 10;
    combatBarEl.innerHTML = `<div class="combat-pill" style="cursor:pointer;" title="Click to change Proficiency Bonus" onclick="quickEditStat('profBonus')"><div class="val">${formatMod(prof)}</div><div class="lbl">Prof</div></div>
      <div class="combat-pill" style="cursor:pointer;" title="Click to change Speed" onclick="quickEditStat('speed')"><div class="val">${speed}ft</div><div class="lbl">Speed</div></div>
      <div class="combat-pill" style="cursor:pointer;" title="Click to change Initiative Bonus" onclick="quickEditStat('initBonus')"><div class="val">${formatMod(init)}</div><div class="lbl">Init</div></div>
      <div class="combat-pill" style="cursor:pointer;" title="Click to change Armor Class" onclick="quickEditStat('ac')"><div class="val">${ac}</div><div class="lbl">AC</div></div>`;
  }

  // Saving Throws List
  const savesEl = document.getElementById('saving-throws-list');
  if(savesEl){
    const statsList = ['str', 'dex', 'con', 'int', 'wis', 'cha'];
    savesEl.innerHTML = statsList.map(function(st){
      const isProf = !!(cs.saveProfs && cs.saveProfs[st]);
      const customBonus = Number((cs.saveCustomBonuses && cs.saveCustomBonuses[st]) || 0);
      const mod = getAbilityMod(cs[st]) + (isProf ? (cs.profBonus||2) : 0) + customBonus;
      return `<div class="save-row" style="cursor:pointer;">
          <div onclick="toggleSaveProf('${st}'); event.stopPropagation();" title="Click dot to toggle proficiency"><span class="pip" style="color:${isProf ? 'var(--gold-bright)' : 'var(--text-faint)'};">${isProf ? '●' : '○'}</span> ${st.toUpperCase()}</div>
          <span class="val" onclick="quickEditSaveBonus('${st}'); event.stopPropagation();" title="Click number to change total save bonus to any number">${formatMod(mod)}</span>
        </div>`;
    }).join('');
  }

  const saveNotesEl = document.getElementById('save-notes');
  if(saveNotesEl) saveNotesEl.textContent = cs.saveNotes || '';

  // Senses List
  const sensesEl = document.getElementById('senses-list');
  if(sensesEl){
    const wisMod = getAbilityMod(cs.wis);
    const intMod = getAbilityMod(cs.int);
    const prof = cs.profBonus || 2;
    const percProfMult = cs.skillProfs ? Number(cs.skillProfs['Perception']||0) : 0;
    const invProfMult = cs.skillProfs ? Number(cs.skillProfs['Investigation']||0) : 0;
    const insProfMult = cs.skillProfs ? Number(cs.skillProfs['Insight']||0) : 0;

    const passPerc = 10 + wisMod + (percProfMult * prof);
    const passInv = 10 + intMod + (invProfMult * prof);
    const passIns = 10 + wisMod + (insProfMult * prof);

    sensesEl.innerHTML = `<div class="sense-row"><span>Pass. Perception</span><span class="val">${passPerc}</span></div>
      <div class="sense-row"><span>Pass. Investigation</span><span class="val">${passInv}</span></div>
      <div class="sense-row"><span>Pass. Insight</span><span class="val">${passIns}</span></div>`;
  }

  const senseNotesEl = document.getElementById('sense-notes');
  if(senseNotesEl) senseNotesEl.textContent = cs.senseNotes || '';

  // Skills List
  const skillsEl = document.getElementById('skills-list-container');
  if(skillsEl){
    const prof = cs.profBonus || 2;
    skillsEl.innerHTML = DND_SKILLS.map(function(sk){
      const profLevel = cs.skillProfs ? Number(cs.skillProfs[sk.name]||0) : 0;
      const customBonus = Number((cs.skillCustomBonuses && cs.skillCustomBonuses[sk.name]) || 0);
      const statMod = getAbilityMod(cs[sk.stat]);
      const totalBonus = statMod + (profLevel * prof) + customBonus;
      const icon = profLevel === 2 ? '★' : (profLevel === 1 ? '●' : '○');
      const iconColor = profLevel === 2 ? '#ffcf40' : (profLevel === 1 ? 'var(--gold-bright)' : 'var(--text-faint)');
      const escapedName = escapeJs(sk.name);
      return `<div class="skill-row" style="cursor:pointer;">
          <span class="pip-btn" style="color:${iconColor}; font-size:12px;" title="Click icon to cycle: None -> Proficient -> Expertise" onclick="toggleSkillProf('${escapedName}'); event.stopPropagation();">${icon}</span>
          <span class="mod-tag" onclick="quickEditSkillBonus('${escapedName}'); event.stopPropagation();">${sk.stat.toUpperCase()}</span>
          <span class="name" onclick="quickEditSkillBonus('${escapedName}'); event.stopPropagation();" title="Click name/number to change bonus to any number">${escapeHtml(sk.name)}</span>
          <span class="bonus" onclick="quickEditSkillBonus('${escapedName}'); event.stopPropagation();" title="Click number to change bonus to any number">${formatMod(totalBonus)}</span>
        </div>`;
    }).join('');
  }

  // Proficiencies Container
  const profEl = document.getElementById('proficiencies-container');
  if(profEl){
    let items = [];
    if(cs.armorProf) items.push('<div style="margin-bottom:4px; font-size:11px;"><strong style="color:var(--gold);">Armor:</strong> ' + escapeHtml(cs.armorProf) + '</div>');
    if(cs.weaponProf) items.push('<div style="margin-bottom:4px; font-size:11px;"><strong style="color:var(--gold);">Weapons:</strong> ' + escapeHtml(cs.weaponProf) + '</div>');
    if(cs.toolProf) items.push('<div style="margin-bottom:4px; font-size:11px;"><strong style="color:var(--gold);">Tools:</strong> ' + escapeHtml(cs.toolProf) + '</div>');
    if(cs.languages) items.push('<div style="margin-bottom:4px; font-size:11px;"><strong style="color:var(--gold);">Languages:</strong> ' + escapeHtml(cs.languages) + '</div>');
    profEl.innerHTML = items.join('') || '<div style="color:var(--text-dim); font-size:11px;">No proficiencies listed.</div>';
  }
}

function toggleSkillProf(skillName){
  if(!state.characterStats) return;
  state.characterStats.skillProfs = state.characterStats.skillProfs || {};
  const current = Number(state.characterStats.skillProfs[skillName]||0);
  state.characterStats.skillProfs[skillName] = (current + 1) % 3; // Cycle: 0 -> 1 -> 2 -> 0
  save();
  renderCharacterStats();
}

function toggleSaveProf(statKey){
  if(!state.characterStats) return;
  state.characterStats.saveProfs = state.characterStats.saveProfs || {};
  state.characterStats.saveProfs[statKey] = !state.characterStats.saveProfs[statKey];
  save();
  renderCharacterStats();
}

function openCharacterStatsModal(){
  const cs = state.characterStats || {};
  const setVal = function(id, val){ const el = document.getElementById(id); if(el) el.value = val !== undefined ? val : ''; };
  setVal('st-class', cs.characterClass || 'Bard');
  setVal('st-subclass', cs.subclass || '');
  setVal('st-level', cs.level || 5);
  setVal('st-species', cs.species || 'Half-Elf');
  setVal('st-subrace', cs.subrace || '');
  setVal('st-str', cs.str || 16);
  setVal('st-dex', cs.dex || 8);
  setVal('st-con', cs.con || 14);
  setVal('st-int', cs.int || 12);
  setVal('st-wis', cs.wis || 10);
  setVal('st-cha', cs.cha || 14);
  setVal('st-prof', cs.profBonus || 2);
  setVal('st-speed', cs.speed || 25);
  setVal('st-init', cs.initBonus || 0);
  setVal('st-ac', cs.ac || 10);
  setVal('st-armor', cs.armorProf || '');
  setVal('st-weapons', cs.weaponProf || '');
  setVal('st-tools', cs.toolProf || '');
  setVal('st-languages', cs.languages || '');
  setVal('st-save-notes', cs.saveNotes || '');
  setVal('st-sense-notes', cs.senseNotes || '');

  // Populate save proficiencies checkboxes
  const saves = ['str', 'dex', 'con', 'int', 'wis', 'cha'];
  saves.forEach(function(s){
    const cb = document.getElementById('st-save-' + s);
    if(cb) cb.checked = !!(cs.saveProfs && cs.saveProfs[s]);
  });

  // Populate skills grid in modal
  const skillsGridEl = document.getElementById('modal-skills-grid');
  if(skillsGridEl){
    skillsGridEl.innerHTML = DND_SKILLS.map(function(sk){
      const val = cs.skillProfs ? Number(cs.skillProfs[sk.name]||0) : 0;
      return '<div style="display:flex; align-items:center; justify-space-between; gap:4px; font-size:11px;">' +
          '<span style="flex:1;">' + escapeHtml(sk.name) + ' (' + sk.stat.toUpperCase() + ')</span>' +
          '<select id="st-skill-' + escapeJs(sk.name) + '" style="font-size:10px; padding:2px 4px; background:var(--panel-2); color:var(--text); border:1px solid var(--border); border-radius:4px;">' +
            '<option value="0" ' + (val===0 ? 'selected' : '') + '>None</option>' +
            '<option value="1" ' + (val===1 ? 'selected' : '') + '>Proficient (1x)</option>' +
            '<option value="2" ' + (val===2 ? 'selected' : '') + '>Expertise (2x)</option>' +
          '</select>' +
        '</div>';
    }).join('');
  }

  const overlay = document.getElementById('stats-settings-overlay');
  if(overlay) overlay.classList.add('open');
}

function closeCharacterStatsModal(){
  const overlay = document.getElementById('stats-settings-overlay');
  if(overlay) overlay.classList.remove('open');
}

function saveCharacterStatsSettings(){
  if(!state.characterStats) state.characterStats = {};
  const cs = state.characterStats;
  const getVal = function(id, isInt){
    const el = document.getElementById(id);
    if(!el) return isInt ? 0 : '';
    return isInt ? (parseInt(el.value, 10) || 0) : el.value.trim();
  };

  cs.characterClass = getVal('st-class', false) || 'Bard';
  cs.subclass = getVal('st-subclass', false);
  cs.level = getVal('st-level', true) || 5;
  cs.species = getVal('st-species', false) || 'Half-Elf';
  cs.subrace = getVal('st-subrace', false);
  cs.str = getVal('st-str', true);
  cs.dex = getVal('st-dex', true);
  cs.con = getVal('st-con', true);
  cs.int = getVal('st-int', true);
  cs.wis = getVal('st-wis', true);
  cs.cha = getVal('st-cha', true);

  cs.profBonus = getVal('st-prof', true);
  cs.speed = getVal('st-speed', true);
  cs.initBonus = getVal('st-init', true);
  cs.ac = getVal('st-ac', true);

  cs.armorProf = getVal('st-armor', false);
  cs.weaponProf = getVal('st-weapons', false);
  cs.toolProf = getVal('st-tools', false);
  cs.languages = getVal('st-languages', false);
  cs.saveNotes = getVal('st-save-notes', false);
  cs.senseNotes = getVal('st-sense-notes', false);

  // Save save proficiencies
  cs.saveProfs = cs.saveProfs || {};
  const saves = ['str', 'dex', 'con', 'int', 'wis', 'cha'];
  saves.forEach(function(s){
    const cb = document.getElementById('st-save-' + s);
    if(cb) cs.saveProfs[s] = cb.checked;
  });

  // Save skill proficiencies from modal grid
  cs.skillProfs = cs.skillProfs || {};
  DND_SKILLS.forEach(function(sk){
    const sel = document.getElementById('st-skill-' + sk.name);
    if(sel) cs.skillProfs[sk.name] = parseInt(sel.value, 10) || 0;
  });

  save();
  closeCharacterStatsModal();
  renderAll();
}


// --- HP TRACKER SYSTEM LOGIC ---

function quickAddTempHP(e){
  if(e) e.stopPropagation();
  const currentTemp = (state.hp && state.hp.temp) ? state.hp.temp : 0;
  const val = prompt('Enter Temporary HP (Temp HP) amount:', currentTemp > 0 ? currentTemp : '5');
  if(val === null) return;
  const tempVal = parseInt(val, 10);
  if(!isNaN(tempVal) && tempVal >= 0){
    setTempHP(tempVal);
  }
}

function setTempHP(amount){
  if(!state.hp) state.hp = { current: 45, max: 45, temp: 0 };
  state.hp.temp = Math.max(0, parseInt(amount, 10) || 0);
  save();
  renderHpTracker();
  syncHpModalInputs();
}

function renderHpTracker(){
  if(!state.hp) state.hp = { current: 45, max: 45, temp: 0 };
  const hp = state.hp;
  if(hp.current === undefined) hp.current = 45;
  if(hp.max === undefined) hp.max = 45;
  if(hp.temp === undefined) hp.temp = 0;

  const curEl = document.getElementById('hp-cur-val');
  const maxEl = document.getElementById('hp-max-val');
  const tempLabel = document.getElementById('hp-temp-label');
  const fillEl = document.getElementById('hp-bar-fill');

  if(curEl) curEl.textContent = hp.current;
  if(maxEl) maxEl.textContent = hp.max;

  if(tempLabel){
    if(hp.temp > 0){
      tempLabel.innerHTML = '🛡️ +' + hp.temp + ' Temp';
      tempLabel.style.display = 'inline-block';
      tempLabel.style.color = '#38bdf8';
      tempLabel.style.background = 'rgba(56,189,248,0.15)';
      tempLabel.style.border = '1px solid #38bdf8';
      tempLabel.style.padding = '1px 5px';
      tempLabel.style.borderRadius = '4px';
    } else {
      tempLabel.style.display = 'none';
    }
  }

  const tempFillEl = document.getElementById('hp-temp-bar-fill');
  if(tempFillEl){
    if(hp.temp > 0 && hp.max > 0){
      const tempPct = Math.min(100, (hp.temp / hp.max) * 100);
      const curPct = Math.min(100, Math.max(0, (hp.current / hp.max) * 100));
      tempFillEl.style.display = 'block';
      tempFillEl.style.left = curPct + '%';
      tempFillEl.style.width = Math.min(100 - curPct, tempPct) + '%';
    } else {
      tempFillEl.style.display = 'none';
    }
  }

  const pct = Math.min(100, Math.max(0, (hp.current / hp.max) * 100));
  if(fillEl){
    fillEl.style.width = pct + '%';
    if(pct > 75){
      fillEl.style.background = 'linear-gradient(90deg, #22c55e, #16a34a)';
    } else if(pct > 40){
      fillEl.style.background = 'linear-gradient(90deg, #f59e0b, #d97706)';
    } else if(pct > 0){
      fillEl.style.background = 'linear-gradient(90deg, #ef4444, #dc2626)';
    } else {
      fillEl.style.background = '#7f1d1d';
    }
  }

  // Also update modal if open
  const modalText = document.getElementById('modal-hp-text');
  if(modalText) modalText.textContent = hp.current + ' / ' + hp.max;
  const modalTemp = document.getElementById('modal-temp-hp-text');
  if(modalTemp){
    modalTemp.style.display = hp.temp > 0 ? 'block' : 'none';
    modalTemp.textContent = '🛡️ +' + hp.temp + ' Temporary HP';
  }
  const modalFill = document.getElementById('modal-hp-bar-fill');
  if(modalFill){
    modalFill.style.width = pct + '%';
    if(pct > 75) modalFill.style.background = 'linear-gradient(90deg, #22c55e, #16a34a)';
    else if(pct > 40) modalFill.style.background = 'linear-gradient(90deg, #f59e0b, #d97706)';
    else modalFill.style.background = 'linear-gradient(90deg, #ef4444, #dc2626)';
  }
}

function applyHpChange(amount){
  if(!state.hp) state.hp = { current: 45, max: 45, temp: 0 };
  const hp = state.hp;
  if(amount < 0){
    let damage = Math.abs(amount);
    if(hp.temp > 0){
      if(hp.temp >= damage){
        hp.temp -= damage;
        damage = 0;
      } else {
        damage -= hp.temp;
        hp.temp = 0;
      }
    }
    if(damage > 0){
      hp.current = Math.max(0, hp.current - damage);
    }
  } else if(amount > 0){
    hp.current = Math.min(hp.max, hp.current + amount);
  }
  save();
  renderHpTracker();
  syncHpModalInputs();
}

function quickDamageHP(e){
  if(e) e.stopPropagation();
  const val = prompt('Enter damage amount:', '5');
  if(val === null) return;
  const dmg = parseInt(val, 10);
  if(!isNaN(dmg) && dmg > 0){
    applyHpChange(-dmg);
  }
}

function quickHealHP(e){
  if(e) e.stopPropagation();
  const val = prompt('Enter heal amount:', '5');
  if(val === null) return;
  const heal = parseInt(val, 10);
  if(!isNaN(heal) && heal > 0){
    applyHpChange(heal);
  }
}

function quickEditCurrentHP(e){
  if(e) e.stopPropagation();
  const val = prompt('Enter Current HP:', state.hp ? state.hp.current : 45);
  if(val === null) return;
  const num = parseInt(val, 10);
  if(!isNaN(num)){
    state.hp.current = Math.max(0, num);
    save();
    renderHpTracker();
  }
}

function quickEditMaxHP(e){
  if(e) e.stopPropagation();
  const val = prompt('Enter Max HP:', state.hp ? state.hp.max : 45);
  if(val === null) return;
  const num = parseInt(val, 10);
  if(!isNaN(num) && num > 0){
    state.hp.max = num;
    if(state.hp.current > num) state.hp.current = num;
    save();
    renderHpTracker();
  }
}

function fullHealHP(){
  if(!state.hp) state.hp = { current: 45, max: 45, temp: 0 };
  state.hp.current = state.hp.max;
  state.hp.temp = 0;
  save();
  renderHpTracker();
  syncHpModalInputs();
}

function openHpQuickModal(e){
  if(e) e.stopPropagation();
  syncHpModalInputs();
  const overlay = document.getElementById('hp-modal-overlay');
  if(overlay) overlay.classList.add('open');
}

function closeHpModal(){
  const overlay = document.getElementById('hp-modal-overlay');
  if(overlay) overlay.classList.remove('open');
}

function syncHpModalInputs(){
  if(!state.hp) state.hp = { current: 45, max: 45, temp: 0 };
  const inpCur = document.getElementById('hp-input-current');
  const inpMax = document.getElementById('hp-input-max');
  const inpTemp = document.getElementById('hp-input-temp');
  if(inpCur) inpCur.value = state.hp.current;
  if(inpMax) inpMax.value = state.hp.max;
  if(inpTemp) inpTemp.value = state.hp.temp || 0;
}

function updateHpFromInputs(){
  if(!state.hp) state.hp = { current: 45, max: 45, temp: 0 };
  const inpCur = document.getElementById('hp-input-current');
  const inpMax = document.getElementById('hp-input-max');
  const inpTemp = document.getElementById('hp-input-temp');

  if(inpMax) state.hp.max = Math.max(1, parseInt(inpMax.value, 10) || 1);
  if(inpCur) state.hp.current = Math.max(0, parseInt(inpCur.value, 10) || 0);
  if(inpTemp) state.hp.temp = Math.max(0, parseInt(inpTemp.value, 10) || 0);

  save();
  renderHpTracker();
}


// --- FEATURES, TRAITS & FEATS LOGIC ---
let activeFeaturesTab = 'ALL';

function filterFeaturesTab(tab){
  activeFeaturesTab = tab;
  ['ALL', 'CLASS', 'SPECIES', 'FEATS', 'BG'].forEach(function(t){
    const btn = document.getElementById('ftab-' + t);
    if(btn){
      btn.className = (t === tab) ? 'btn small' : 'btn ghost small';
    }
  });
  renderFeaturesView();
}

function initDefaultFeatures(){
  if(!state.features) state.features = {};
  if(!state.features.items || !state.features.items.length){
    state.features.items = [
      { id: 'f1', category: 'CLASS', title: 'Bard Features', name: 'Hit Points', source: 'PHB, pg. 52', desc: 'Hit Dice: 1d8 per Bard level.' },
      { id: 'f2', category: 'CLASS', title: 'Bard Features', name: 'Proficiencies', source: 'PHB, pg. 52', desc: 'Armor: Light Armor\nWeapons: Simple Weapons, Hand Crossbows, Longswords, Rapiers, Shortswords\nTools: Three musical instruments of your choice.' },
      { id: 'f3', category: 'CLASS', title: 'Bard Features', name: 'Spellcasting', source: 'PHB, pg. 52', desc: 'You can cast known bard spells using CHA as your spellcasting modifier (Spell DC 12, Spell Attack +4) and known bard spells as rituals if they have the ritual tag. You can use a musical instrument as a spellcasting focus.' },
      { id: 'f4', category: 'CLASS', title: 'Bard Features', name: 'Bardic Inspiration', source: 'PHB, pg. 53', desc: 'As a bonus action, a creature (other than you) within 60 ft. that can hear you gains an inspiration die (1d6). For 10 minutes, the creature can add it to one ability check, attack roll, or saving throw.', maxUses: 2, usedUses: 0, resetType: 'Long Rest' },
      { id: 'f5', category: 'CLASS', title: 'Bard Features', name: 'Jack of All Trades', source: 'PHB, pg. 54', desc: 'You can add half your proficiency bonus, rounded down (+1), to any ability check you make that doesn\'t already include it.' },
      { id: 'f6', category: 'CLASS', title: 'Bard Features', name: 'Song of Rest', source: 'PHB, pg. 54', desc: 'You can use soothing music or oration to help revitalize your wounded allies during a short rest. Regain an extra +1d6 HP.' },
      { id: 'f7', category: 'SPECIES', title: 'Half-Elf Traits', name: 'Darkvision', source: 'PHB, pg. 39', desc: 'Accustomed to twilit forests and the night sky, you have superior vision in dark and dim conditions. You can see in dim light within 60 feet as if it were bright light, and in darkness as if dim light.' },
      { id: 'f8', category: 'SPECIES', title: 'Half-Elf Traits', name: 'Fey Ancestry', source: 'PHB, pg. 39', desc: 'You have advantage on saving throws against being charmed, and magic can\'t put you to sleep.' },
      { id: 'f9', category: 'FEATS', title: 'Feats', name: 'War Caster', source: 'PHB, pg. 170', desc: 'You have advantage on CON saving throws to maintain concentration on a spell when taking damage; perform somatic components even with weapons equipped; cast spells as opportunity attacks.' }
    ];
  }
  if(!state.features.backgroundInfo){
    if(!state.characterStats) state.characterStats = {};
  if(document.getElementById('bg-class')) state.characterStats.characterClass = document.getElementById('bg-class').value.trim() || 'Bard';
  if(document.getElementById('bg-species')) state.characterStats.species = document.getElementById('bg-species').value.trim() || 'Half-Elf';
  if(document.getElementById('bg-level')) state.characterStats.level = parseInt(document.getElementById('bg-level').value, 10) || 5;
  renderCharacterStats();
  state.features.backgroundInfo = {
      name: 'Entertainer',
      featureName: 'By Popular Demand',
      alignment: 'Chaotic Good',
      ideals: 'Art & Expression: Beauty and song uplift the realm.',
      bonds: 'My instrument is my most treasured possession.',
      flaws: 'I can\'t resist a good story or scandal.'
    };
  }
}

function renderFeaturesView(){
  initDefaultFeatures();
  const container = document.getElementById('features-list-content');
  if(!container) return;

  const items = state.features.items || [];
  const bg = state.features.backgroundInfo || {};
  const cs = state.characterStats || {};
  if(document.getElementById('bg-class')) document.getElementById('bg-class').value = cs.characterClass || 'Bard';
  if(document.getElementById('bg-species')) document.getElementById('bg-species').value = cs.species || 'Half-Elf';
  if(document.getElementById('bg-level')) document.getElementById('bg-level').value = cs.level || 5;

  let html = '';

  // Render Background & Alignment section if tab is ALL or BG
  if(activeFeaturesTab === 'ALL' || activeFeaturesTab === 'BG'){
    html += '<div style="background:rgba(0,0,0,0.3); border:1px solid var(--border-bright); border-radius:8px; padding:16px;">' +
        '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">' +
          '<div style="font-family:Cinzel,serif; font-size:16px; font-weight:700; color:var(--gold-bright);">📜 Character Identity, Background & Alignment</div>' +
          '<button class="btn ghost small" onclick="openEditBackgroundModal()">⚙️ Edit</button>' +
        '</div>' +
        '<div class="form-grid" style="grid-template-columns:1fr 1fr 1fr; gap:12px; font-size:13px; margin-bottom:8px;">' +
          '<div><b>Class & Level:</b> <span style="color:#4ade80; font-weight:bold;">Lvl ' + (cs.level || 5) + ' ' + escapeHtml(cs.characterClass || 'Bard') + (cs.subclass ? ' (' + escapeHtml(cs.subclass) + ')' : '') + '</span></div>' +
          '<div><b>Race / Species:</b> <span style="color:#38bdf8; font-weight:bold;">' + escapeHtml(cs.species || 'Half-Elf') + (cs.subrace ? ' (' + escapeHtml(cs.subrace) + ')' : '') + '</span></div>' +
          '<div><b>Alignment:</b> <span style="color:var(--gold-bright); font-weight:bold;">' + escapeHtml(bg.alignment || 'Chaotic Good') + '</span></div>' +
        '</div>' +
        '<div class="form-grid" style="grid-template-columns:1fr 1fr; gap:12px; font-size:13px;">' +
          '<div><b>Background:</b> ' + escapeHtml(bg.name || 'Entertainer') + (bg.featureName ? ' (' + escapeHtml(bg.featureName) + ')' : '') + '</div>' +
        '</div>' +
        (bg.ideals ? '<div style="font-size:12px; margin-top:8px; color:var(--text-dim);"><b>Ideals:</b> ' + escapeHtml(bg.ideals) + '</div>' : '') +
        (bg.bonds ? '<div style="font-size:12px; margin-top:4px; color:var(--text-dim);"><b>Bonds:</b> ' + escapeHtml(bg.bonds) + '</div>' : '') +
        (bg.flaws ? '<div style="font-size:12px; margin-top:4px; color:var(--text-dim);"><b>Flaws:</b> ' + escapeHtml(bg.flaws) + '</div>' : '') +
      '</div>';
  }

  // Filter items based on active tab
  let filteredItems = items;
  if(activeFeaturesTab !== 'ALL' && activeFeaturesTab !== 'BG'){
    filteredItems = items.filter(function(i){ return i.category === activeFeaturesTab; });
  }

  // Group items by Section Title dynamically matching active Class & Species
  const currentClass = (cs && cs.characterClass) ? cs.characterClass : 'Bard';
  const currentSpecies = (cs && cs.species) ? cs.species : 'Half-Elf';

  const groups = {};
  filteredItems.forEach(function(item){
    let grpTitle = item.title || '';
    if(item.category === 'CLASS' || grpTitle.includes('Features') || grpTitle === 'Bard Features'){
      grpTitle = currentClass.toUpperCase() + ' FEATURES';
    } else if(item.category === 'SPECIES' || grpTitle.includes('Traits') || grpTitle === 'Half-Elf Traits'){
      grpTitle = currentSpecies.toUpperCase() + ' TRAITS';
    } else if(item.category === 'FEATS' || grpTitle === 'Feats'){
      grpTitle = 'FEATS';
    }
    if(!grpTitle) grpTitle = 'FEATURES & TRAITS';
    if(!groups[grpTitle]) groups[grpTitle] = [];
    groups[grpTitle].push(item);
  });

  Object.keys(groups).forEach(function(groupTitle){
    html += '<div style="background:rgba(0,0,0,0.25); border:1px solid var(--border); border-radius:8px; padding:16px;">' +
        '<div style="font-family:Cinzel,serif; font-size:18px; font-weight:700; color:#ef4444; border-bottom:1px solid rgba(239,68,68,0.3); padding-bottom:6px; margin-bottom:12px;">' + escapeHtml(groupTitle) + '</div>' +
        '<div style="display:flex; flex-direction:column; gap:14px;">';

    groups[groupTitle].forEach(function(f){
      const fid = escapeJs(f.id);
      let pipsHtml = '';
      if(f.maxUses > 0){
        let pips = '';
        for(let u = 0; u < f.maxUses; u++){
          const isUsed = u < (f.usedUses || 0);
          pips += '<button type="button" class="slot-pip' + (isUsed ? ' used' : '') + '" style="width:16px; height:16px; font-size:10px;" onclick="toggleFeatureUse(\'' + fid + '\', ' + u + ')">' + (isUsed ? '✕' : '■') + '</button>';
        }
        pipsHtml = '<div style="display:inline-flex; align-items:center; gap:6px; background:rgba(0,0,0,0.3); padding:4px 8px; border-radius:4px; border:1px solid var(--border); margin-top:6px; font-size:11px;">' +
            '<span style="font-weight:bold;">' + escapeHtml(f.name) + ': ' + (f.maxUses - (f.usedUses || 0)) + '/' + f.maxUses + ' Uses</span> ' +
            '<div style="display:flex; gap:3px;">' + pips + '</div>' +
            '<span style="color:var(--text-muted);">/ ' + escapeHtml(f.resetType || 'Long Rest') + '</span>' +
          '</div>';
      }

      const descFormatted = escapeHtml(f.desc || '').replace(/\n/g, '<br>');

      html += '<div style="border-left:3px solid var(--gold-bright); padding-left:10px; position:relative;">' +
          '<div style="display:flex; justify-content:space-between; align-items:baseline;">' +
            '<div style="font-weight:bold; font-size:14px; color:var(--text);">' + escapeHtml(f.name) + (f.source ? ' <span style="font-weight:normal; font-size:11px; color:var(--text-muted); font-style:italic;">· ' + escapeHtml(f.source) + '</span>' : '') + '</div>' +
            '<div style="display:flex; gap:4px;">' +
              '<button class="btn ghost small" style="padding:1px 6px; font-size:11px;" onclick="editFeatureItem(\'' + fid + '\')">Edit</button>' +
              '<button class="btn danger small" style="padding:1px 6px; font-size:11px;" onclick="deleteFeatureItem(\'' + fid + '\')">✕</button>' +
            '</div>' +
          '</div>' +
          '<div style="font-size:12px; color:var(--text-dim); margin-top:4px; line-height:1.4;">' + descFormatted + '</div>' +
          pipsHtml +
        '</div>';
    });

    html += '</div></div>';
  });

  if(!filteredItems.length && activeFeaturesTab !== 'BG'){
    html += '<div class="spell-empty">No features found in this category. Click "+ Add Feature / Trait" above to create one.</div>';
  }

  container.innerHTML = html;
}

function toggleFeatureUse(id, index){
  initDefaultFeatures();
  const f = (state.features.items || []).find(function(i){ return i.id === id; });
  if(!f) return;
  const currentUsed = f.usedUses || 0;
  if(index < currentUsed){
    f.usedUses = Math.max(0, currentUsed - 1);
  } else {
    f.usedUses = Math.min(f.maxUses, currentUsed + 1);
  }
  save();
  renderFeaturesView();
}

function openAddFeatureModal(){
  document.getElementById('feature-modal-title').textContent = 'Add Feature / Trait';
  document.getElementById('fe-id').value = '';
  document.getElementById('fe-category').value = activeFeaturesTab !== 'ALL' && activeFeaturesTab !== 'BG' ? activeFeaturesTab : 'CLASS';
  document.getElementById('fe-title').value = 'Class Features';
  document.getElementById('fe-name').value = '';
  document.getElementById('fe-source').value = 'PHB, pg. 52';
  document.getElementById('fe-max-uses').value = 0;
  document.getElementById('fe-reset-type').value = 'Long Rest';
  document.getElementById('fe-desc').value = '';

  const overlay = document.getElementById('feature-edit-overlay');
  if(overlay) overlay.classList.add('open');
}

function editFeatureItem(id){
  initDefaultFeatures();
  const f = (state.features.items || []).find(function(i){ return i.id === id; });
  if(!f) return;
  document.getElementById('feature-modal-title').textContent = 'Edit Feature / Trait';
  document.getElementById('fe-id').value = f.id;
  document.getElementById('fe-category').value = f.category || 'CLASS';
  document.getElementById('fe-title').value = f.title || '';
  document.getElementById('fe-name').value = f.name || '';
  document.getElementById('fe-source').value = f.source || '';
  document.getElementById('fe-max-uses').value = f.maxUses || 0;
  document.getElementById('fe-reset-type').value = f.resetType || 'Long Rest';
  document.getElementById('fe-desc').value = f.desc || '';

  const overlay = document.getElementById('feature-edit-overlay');
  if(overlay) overlay.classList.add('open');
}

function closeFeatureEditModal(){
  const overlay = document.getElementById('feature-edit-overlay');
  if(overlay) overlay.classList.remove('open');
}

function saveFeatureItem(){
  initDefaultFeatures();
  const name = document.getElementById('fe-name').value.trim();
  if(!name){ alert('Please enter a feature name.'); return; }
  const id = document.getElementById('fe-id').value;

  const data = {
    category: document.getElementById('fe-category').value,
    title: document.getElementById('fe-title').value.trim() || 'Custom Features',
    name: name,
    source: document.getElementById('fe-source').value.trim(),
    maxUses: parseInt(document.getElementById('fe-max-uses').value, 10) || 0,
    resetType: document.getElementById('fe-reset-type').value,
    desc: document.getElementById('fe-desc').value.trim()
  };

  if(id){
    const item = (state.features.items || []).find(function(i){ return i.id === id; });
    if(item){
      Object.assign(item, data);
    }
  } else {
    data.id = 'f_' + Date.now();
    data.usedUses = 0;
    state.features.items = state.features.items || [];
    state.features.items.push(data);
  }

  save();
  closeFeatureEditModal();
  renderFeaturesView();
}

function deleteFeatureItem(id){
  if(!confirm('Delete this feature?')) return;
  initDefaultFeatures();
  state.features.items = (state.features.items || []).filter(function(i){ return i.id !== id; });
  save();
  renderFeaturesView();
}

function openEditBackgroundModal(){
  initDefaultFeatures();
  const bg = state.features.backgroundInfo || {};
  const cs = state.characterStats || {};

  const elClass = document.getElementById('bg-class');
  if(elClass) elClass.value = cs.characterClass || 'Bard';

  const elSpecies = document.getElementById('bg-species');
  if(elSpecies) elSpecies.value = cs.species || 'Half-Elf';

  const elLevel = document.getElementById('bg-level');
  if(elLevel) elLevel.value = cs.level || 5;

  document.getElementById('bg-name').value = bg.name || '';
  document.getElementById('bg-feature').value = bg.featureName || '';
  document.getElementById('bg-alignment').value = bg.alignment || '';
  document.getElementById('bg-ideals').value = bg.ideals || '';
  document.getElementById('bg-bonds').value = bg.bonds || '';
  document.getElementById('bg-flaws').value = bg.flaws || '';

  const overlay = document.getElementById('background-edit-overlay');
  if(overlay) overlay.classList.add('open');
}

function closeBackgroundModal(){
  const overlay = document.getElementById('background-edit-overlay');
  if(overlay) overlay.classList.remove('open');
}

function saveBackgroundInfo(){
  initDefaultFeatures();
  if(!state.characterStats) state.characterStats = {};
  const cs = state.characterStats;

  const elClass = document.getElementById('bg-class');
  if(elClass) cs.characterClass = elClass.value.trim() || 'Bard';

  const elSpecies = document.getElementById('bg-species');
  if(elSpecies) cs.species = elSpecies.value.trim() || 'Half-Elf';

  const elLevel = document.getElementById('bg-level');
  if(elLevel){
    const lvl = parseInt(elLevel.value, 10) || 5;
    cs.level = lvl;
    cs.profBonus = Math.floor((lvl - 1) / 4) + 2;
  }

  state.features.backgroundInfo = {
    name: document.getElementById('bg-name').value.trim(),
    featureName: document.getElementById('bg-feature').value.trim(),
    alignment: document.getElementById('bg-alignment').value.trim(),
    ideals: document.getElementById('bg-ideals').value.trim(),
    bonds: document.getElementById('bg-bonds').value.trim(),
    flaws: document.getElementById('bg-flaws').value.trim()
  };

  save();
  closeBackgroundModal();
  renderAll();
}

function renderAll(){
  renderCharacterStats();
  switchMainTab(state.activeTab || "inventory");
  renderHeader();
  renderDoll();
  renderActiveEffects();
  renderDeathSaves();
  renderAttunementMenu();
  renderSpellbookMenu();
  renderGrid();
  renderDetail();
  if(typeof renderFeaturesView === 'function') renderFeaturesView();
  if(typeof renderHpTracker === 'function') renderHpTracker();
}

function renderHeader(){
  const cs = state.characterStats || {};
  const subEl = document.getElementById('campaign-sub');
  if(subEl){
    const classStr = 'Lvl ' + (cs.level || 5) + ' ' + (cs.characterClass || 'Bard') + (cs.subclass ? ' (' + cs.subclass + ')' : '') + ' · ' + (cs.species || 'Half-Elf') + (cs.subrace ? ' (' + cs.subrace + ')' : '');
    subEl.textContent = (state.campaign || 'Party Inventory Ledger') + ' | ' + classStr;
  }

  const currency = state.currency || { platinum:0, gold:0, electrum:0, silver:0, copper:0 };
  const coinOrder = [
    ['pp', currency.platinum || 0],
    ['gp', currency.gold || 0],
    ['ep', currency.electrum || 0],
    ['sp', currency.silver || 0],
    ['cp', currency.copper || 0]
  ];
  const totalCoins = coinOrder.reduce((sum, item)=>sum + (Number(item[1]) || 0), 0);
  
  const coinTotEl = document.getElementById('coin-total');
  if(coinTotEl) coinTotEl.textContent = totalCoins.toLocaleString();
  
  const coinBrkEl = document.getElementById('coin-breakdown');
  if(coinBrkEl) coinBrkEl.innerHTML = coinOrder.map(function(item){ return '<span>' + item[1].toLocaleString() + ' ' + item[0] + '</span>'; }).join('');
  
  const totalW = (state.items||[]).reduce((s,i)=> s + (i.weight||0)*(i.qty||1), 0);
  const weightValEl = document.getElementById('weight-val');
  if(weightValEl) weightValEl.textContent = totalW.toFixed(1) + ' / ' + (state.capacity||150) + ' lb';
  
  const pct = Math.min(100, (totalW/(state.capacity||1))*100);
  const fill = document.getElementById('weight-fill');
  if(fill){
    fill.style.width = pct + '%';
    fill.classList.toggle('over', totalW > state.capacity);
  }
  const weightPill = document.getElementById('weight-pill');
  if(weightPill) weightPill.classList.toggle('warn', totalW > state.capacity);
}

let draggingItemId = null;

function renderDoll(){
  const doll = document.getElementById('doll');
  if(!doll) return;
  doll.innerHTML = '';
  Object.keys(SLOT_LABELS).forEach(slotKey=>{
    const equipped = (state.items||[]).find(i=>i.equipped && i.slot===slotKey);
    const div = document.createElement('div');
    div.className = 'slot' + (equipped ? ' filled' : '');
    div.id = 'slot-' + slotKey;
    if(equipped) div.dataset.rarity = equipped.rarity;
    div.innerHTML = '<span class="slot-label">' + SLOT_LABELS[slotKey] + '</span>' +
      '<span class="icon">' + (equipped ? (equipped.icon||'❔') : SLOT_ICONS[slotKey]) + '</span>' +
      (equipped ? '<span class="item-name">' + escapeHtml(equipped.name) + '</span>' : '');
    div.onclick = ()=> slotClicked(slotKey, equipped);
    if(equipped){
      div.draggable = true;
      div.ondragstart = e=>{ draggingItemId = equipped.id; e.dataTransfer.setData('text/plain', equipped.id); e.dataTransfer.effectAllowed='move'; div.classList.add('dragging'); };
      div.ondragend = ()=>{ div.classList.remove('dragging'); draggingItemId = null; };
    }
    div.ondragover = e=>{
      const draggedId = draggingItemId;
      const dragged = (state.items||[]).find(i=>i.id===draggedId);
      if(dragged && dragged.slot === slotKey){
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        div.classList.add('drag-over');
      }
    };
    div.ondragleave = ()=> div.classList.remove('drag-over');
    div.ondrop = e=>{
      e.preventDefault();
      div.classList.remove('drag-over');
      const id = e.dataTransfer.getData('text/plain');
      const item = (state.items||[]).find(i=>i.id===id);
      if(!item || item.slot !== slotKey) return;
      state.items.forEach(i=>{ if(i.slot===slotKey && i.id!==item.id) i.equipped=false; });
      item.equipped = true;
      save(); renderAll();
    };
    doll.appendChild(div);
  });
}

function slotClicked(slotKey, equipped){
  if(equipped){
    state.selectedId = equipped.id;
    save();
    renderGrid();
    renderDetail();
    return;
  }
  const candidates = (state.items||[]).filter(i=>i.slot===slotKey && !i.equipped);
  if(candidates.length===0){ return; }
  if(candidates.length===1){
    candidates[0].equipped = true;
    save(); renderAll();
    return;
  }
  const names = candidates.map((c,idx)=> (idx+1)+'. '+c.name).join('\n');
  const pick = prompt('Multiple items fit this slot. Enter a number:\n' + names);
  const idx = parseInt(pick,10)-1;
  if(candidates[idx]){
    candidates[idx].equipped = true;
    save(); renderAll();
  }
}



function renderDeathSaves(){
  const menu = document.getElementById('death-save-menu');
  if(!menu) return;
  const ds = state.deathSaves;
  const makePips = (kind, values) => values.map((on, idx)=>'<button type="button" class="death-save-pip ' + kind + (on ? ' on' : '') + '" onclick="toggleDeathSave(\'' + kind + '\', ' + idx + ')">' + (on ? '●' : '○') + '</button>').join('');
  menu.innerHTML = ds.open ? '<div class="death-save-body">' +
      '<div class="death-save-grid">' +
        '<div class="death-save-group">' +
          '<div class="death-save-group-title">Successes</div>' +
          '<div class="death-save-pips">' + makePips('success', ds.successes) + '</div>' +
        '</div>' +
        '<div class="death-save-group">' +
          '<div class="death-save-group-title">Failures</div>' +
          '<div class="death-save-pips">' + makePips('failure', ds.failures) + '</div>' +
        '</div>' +
      '</div>' +
      '<div class="death-save-actions">' +
        '<button class="btn ghost small" onclick="resetDeathSaves()">Reset</button>' +
      '</div>' +
    '</div>' : '<div class="hint">Death saves are hidden. Use the toggle to open the tracker.</div>';
  const toggleBtn = document.getElementById('death-save-toggle');
  if(toggleBtn) toggleBtn.textContent = ds.open ? 'Hide' : 'Show';
}

function renderAttunementMenu(){
  const menu = document.getElementById('attunement-menu');
  if(!menu) return;
  const att = state.attunements;
  const slots = att.slots.map((id, idx)=>{
    const item = (state.items||[]).find(i=>i.id===id);
    if(!item){
      return '<div class="attunement-slot">' +
        '<div class="attunement-slot-title">Slot ' + (idx+1) + '</div>' +
        '<div class="attunement-slot-empty">' +
          '<div>' +
            '<div class="attunement-slot-name">Empty</div>' +
            '<div class="attunement-slot-meta">Add an item that requires attunement</div>' +
          '</div>' +
          '<button class="btn ghost small" onclick="pickAttunementItem(' + idx + ')">Add</button>' +
        '</div>' +
      '</div>';
    }
    return '<div class="attunement-slot">' +
      '<div class="attunement-slot-title">Slot ' + (idx+1) + '</div>' +
      '<div class="attunement-slot-item">' +
        '<div class="attunement-slot-icon">' + (item.icon || '❔') + '</div>' +
        '<div>' +
          '<div class="attunement-slot-name">' + escapeHtml(item.name) + '</div>' +
          '<div class="attunement-slot-meta">' + item.rarity + ' · ' + item.type + '</div>' +
        '</div>' +
        '<button class="btn ghost small" onclick="clearAttunementSlot(' + idx + ')">Remove</button>' +
      '</div>' +
    '</div>';
  }).join('');
  menu.innerHTML = att.open ? '<div class="attunement-body"><div class="attunement-slots">' + slots + '</div><div class="attunement-actions"><button class="btn ghost small" onclick="resetAttunements()">Clear All</button></div></div>' : '<div class="hint">Attunement slots are hidden. Use the toggle to open the tracker.</div>';
  const toggleBtn = document.getElementById('attunement-toggle');
  if(toggleBtn) toggleBtn.textContent = att.open ? 'Hide' : 'Show';
}

function renderSpellbookMenu(){
  const menu = document.getElementById('spellbook-menu');
  if(!menu) return;
  if(!menu.dataset.initialized){
    menu.dataset.initialized = '1';
    menu.innerHTML = '<div class="spell-slots-card" id="spell-slots-container"></div>' +
      '<div class="spellbook-filter-bar">' +
        '<input type="text" id="spell-search-input" placeholder="🔍 Search spells by name, description, damage, or tags..." value="' + escapeHtml(state.spellbook.query||'') + '" oninput="updateSpellSearch(this.value)">' +
        '<select id="spell-class-filter" onchange="updateSpellClassFilter(this.value)">' +
          '<option value="">All Classes</option>' +
          '<option value="Bard">Bard</option>' +
          '<option value="Cleric">Cleric</option>' +
          '<option value="Druid">Druid</option>' +
          '<option value="Paladin">Paladin</option>' +
          '<option value="Ranger">Ranger</option>' +
          '<option value="Sorcerer">Sorcerer</option>' +
          '<option value="Warlock">Warlock</option>' +
          '<option value="Wizard">Wizard</option>' +
          '<option value="Artificer">Artificer</option>' +
        '</select>' +
        '<select id="spell-level-filter" onchange="updateSpellLevelFilter(this.value)">' +
          '<option value="">All Levels</option>' +
          '<option value="0">Cantrips</option>' +
          '<option value="1">Level 1</option>' +
          '<option value="2">Level 2</option>' +
          '<option value="3">Level 3</option>' +
          '<option value="4">Level 4</option>' +
          '<option value="5">Level 5</option>' +
          '<option value="6">Level 6</option>' +
          '<option value="7">Level 7</option>' +
          '<option value="8">Level 8</option>' +
          '<option value="9">Level 9</option>' +
        '</select>' +
        '<select id="spell-school-filter" onchange="updateSpellSchoolFilter(this.value)">' +
          '<option value="">All Schools</option>' +
          '<option value="Abjuration">Abjuration</option>' +
          '<option value="Conjuration">Conjuration</option>' +
          '<option value="Divination">Divination</option>' +
          '<option value="Enchantment">Enchantment</option>' +
          '<option value="Evocation">Evocation</option>' +
          '<option value="Illusion">Illusion</option>' +
          '<option value="Necromancy">Necromancy</option>' +
          '<option value="Transmutation">Transmutation</option>' +
        '</select>' +
        '<select id="spell-sort-by" onchange="updateSpellSortBy(this.value)">' +
          '<option value="level-asc">Sort: Level (Asc)</option>' +
          '<option value="level-desc">Sort: Level (Desc)</option>' +
          '<option value="name">Sort: Name (A-Z)</option>' +
          '<option value="class">Sort: Class (A-Z)</option>' +
          '<option value="school">Sort: School</option>' +
        '</select>' +
        '<button class="btn ghost small" onclick="clearSpellFilters()">🧹 Clear Filters</button>' +
        '<button class="btn ghost small" onclick="openMaxSpellsModal()">⚙️ Max Spells Limits</button>' +
        '<button class="btn ghost small" onclick="refreshSpellCatalog()">Reload Catalog</button>' +
      '</div>' +
      '<div class="spellbook-body">' +
        '<div style="display:flex; justify-content:space-between; align-items:center; margin:16px 0 12px; flex-wrap:wrap; gap:10px;">' +
          '<div>' +
            '<div class="panel-title" style="font-size:18px; margin:0;">📖 My Spell List (Prepared & Learned)</div>' +
            '<div class="spell-status" id="spell-list-status" style="margin-top:2px;">0 saved</div>' +
          '</div>' +
          '<div style="display:flex; gap:8px; align-items:center;">' +
            '<input type="text" id="my-spells-search" placeholder="🔍 Search my spells..." oninput="updateMySpellsSearch(this.value)" style="padding:6px 12px; font-size:12px; max-width:200px; border-radius:6px; background:rgba(0,0,0,0.3); border:1px solid var(--border); color:var(--text);">' +
            '<button class="btn small" onclick="openSpellCatalogModal()" style="font-size:12px; font-weight:bold; background:linear-gradient(180deg, var(--gold-bright), #8a641d); color:#000; box-shadow:0 0 8px rgba(234,179,8,0.3);">📜 + Browse & Add Spells (Full Catalog)</button>' +
            '<button class="btn ghost small" onclick="openMaxSpellsModal()">⚙️ Max Limits</button>' +
          '</div>' +
        '</div>' +
        '<div class="spell-list" id="spell-list"></div>' +
      '</div>';
  }
  renderSpellSlots();
  renderSpellbookContents();
  const toggleBtn = document.getElementById('spellbook-toggle');
  if(toggleBtn) toggleBtn.textContent = state.spellbook.open ? 'Hide' : 'Show';
}

function clearSpellFilters(){
  state.spellbook.query = '';
  state.spellbook.classFilter = '';
  state.spellbook.levelFilter = '';
  state.spellbook.schoolFilter = '';
  state.spellbook.sortBy = 'level-asc';
  const searchEl = document.getElementById('spell-search-input'); if(searchEl) searchEl.value = '';
  const classEl = document.getElementById('spell-class-filter'); if(classEl) classEl.value = '';
  const lvlEl = document.getElementById('spell-level-filter'); if(lvlEl) lvlEl.value = '';
  const schEl = document.getElementById('spell-school-filter'); if(schEl) schEl.value = '';
  const sortEl = document.getElementById('spell-sort-by'); if(sortEl) sortEl.value = 'level-asc';
  save();
  renderSpellbookContents();
}

function renderSpellSlots(){
  const container = document.getElementById('spell-slots-container');
  if(!container) return;
  const slots = state.spellSlots || { max:{}, used:{} };

  let activeLevels = [];
  for(let lvl=1; lvl<=9; lvl++){
    if((slots.max[lvl] || 0) > 0) activeLevels.push(lvl);
  }

  let html = '<div class="spell-slots-header">' +
      '<div class="spell-slots-title">✨ Spell Slots Tracker</div>' +
      '<div style="display:flex; gap:6px;">' +
        '<button class="btn ghost small" onclick="restSpellSlots()">✨ Long Rest (Reset Slots)</button>' +
        '<button class="btn ghost small" onclick="openSlotSettingsModal()">⚙️ Slot Settings</button>' +
      '</div>' +
    '</div>';

  if(activeLevels.length === 0){
    html += '<div class="hint">No active spell slots configured. Click "⚙️ Slot Settings" to add spell slots for your level.</div>';
  } else {
    html += '<div class="spell-slots-grid">';
    activeLevels.forEach(function(lvl){
      const maxCount = slots.max[lvl] || 0;
      const usedCount = slots.used[lvl] || 0;
      let pips = '';
      for(let i=0; i<maxCount; i++){
        const isUsed = i < usedCount;
        pips += '<button type="button" class="slot-pip' + (isUsed ? ' used' : '') + '" title="Level ' + lvl + ' slot ' + (i+1) + '" onclick="toggleSpellSlot(' + lvl + ', ' + i + ')">' + (isUsed ? '✕' : '●') + '</button>';
      }
      html += '<div class="slot-level-box">' +
          '<div class="slot-level-title">Level ' + lvl + ' (' + (maxCount - usedCount) + '/' + maxCount + ')</div>' +
          '<div class="slot-pips">' + pips + '</div>' +
        '</div>';
    });
    html += '</div>';
  }

  container.innerHTML = html;
}

function toggleSpellSlot(lvl, pipIndex){
  state.spellSlots.used = state.spellSlots.used || {};
  const currentUsed = state.spellSlots.used[lvl] || 0;
  if(pipIndex < currentUsed){
    state.spellSlots.used[lvl] = Math.max(0, currentUsed - 1);
  } else {
    const maxVal = state.spellSlots.max[lvl] || 0;
    state.spellSlots.used[lvl] = Math.min(maxVal, currentUsed + 1);
  }
  save();
  renderSpellSlots();
}

function restSpellSlots(){
  for(let lvl=1; lvl<=9; lvl++){
    if(state.spellSlots.used) state.spellSlots.used[lvl] = 0;
  }
  save();
  renderSpellSlots();
}

function openSlotSettingsModal(){
  const grid = document.getElementById('slot-inputs-grid');
  if(!grid) return;
  const slots = state.spellSlots || { max:{} };
  let html = '';
  for(let lvl=1; lvl<=9; lvl++){
    const val = slots.max[lvl] || 0;
    html += '<div class="form-row">' +
        '<label>Level ' + lvl + ' Slots</label>' +
        '<input type="number" id="s-slot-' + lvl + '" value="' + val + '" min="0" max="10">' +
      '</div>';
  }
  grid.innerHTML = html;
  const overlay = document.getElementById('slot-settings-overlay');
  if(overlay) overlay.classList.add('open');
}

function closeSlotSettingsModal(){
  const overlay = document.getElementById('slot-settings-overlay');
  if(overlay) overlay.classList.remove('open');
}

function saveSlotSettings(){
  state.spellSlots.max = state.spellSlots.max || {};
  state.spellSlots.used = state.spellSlots.used || {};
  for(let lvl=1; lvl<=9; lvl++){
    const input = document.getElementById('s-slot-' + lvl);
    if(input){
      const maxVal = Math.max(0, parseInt(input.value, 10) || 0);
      state.spellSlots.max[lvl] = maxVal;
      if((state.spellSlots.used[lvl] || 0) > maxVal){
        state.spellSlots.used[lvl] = maxVal;
      }
    }
  }
  save();
  closeSlotSettingsModal();
  renderSpellSlots();
}

function applySlotPreset(preset){
  const presets = {
    full: { 1:4, 2:3, 3:2, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0 },
    high: { 1:4, 2:3, 3:3, 4:3, 5:2, 6:1, 7:0, 8:0, 9:0 },
    reset: { 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0 }
  };
  const choice = presets[preset] || presets.reset;
  for(let lvl=1; lvl<=9; lvl++){
    const el = document.getElementById('s-slot-' + lvl);
    if(el) el.value = choice[lvl] || 0;
  }
}

function updateSpellClassFilter(val){
  state.spellbook.classFilter = val;
  renderSpellbookContents();
}

function updateSpellLevelFilter(val){
  state.spellbook.levelFilter = val;
  renderSpellbookContents();
}

function updateSpellSchoolFilter(val){
  state.spellbook.schoolFilter = val;
  renderSpellbookContents();
}

function updateSpellSortBy(val){
  state.spellbook.sortBy = val;
  renderSpellbookContents();
}

function updateSpellSearch(value){
  state.spellbook.query = value;
  renderSpellbookContents();
}

function parseLevelNum(levelText){
  if (levelText === undefined || levelText === null) return 0;
  const str = String(levelText).toLowerCase();
  if (str.includes('cantrip')) return 0;
  const m = str.match(/\d+/);
  return m ? parseInt(m[0], 10) : 0;
}


let mySpellsFilterQuery = '';

function updateMySpellsSearch(val){
  mySpellsFilterQuery = (val || '').toLowerCase().trim();
  renderSpellbookContents();
}

function openSpellCatalogModal(){
  const overlay = document.getElementById('spell-catalog-overlay');
  if(overlay) overlay.classList.add('open');
  renderSpellbookContents();
}

function closeSpellCatalogModal(){
  const overlay = document.getElementById('spell-catalog-overlay');
  if(overlay) overlay.classList.remove('open');
}

function renderSpellbookContents(){
  const sb = state.spellbook;
  const query = (sb.query || '').trim().toLowerCase();
  const classFilter = sb.classFilter || '';
  const levelFilter = sb.levelFilter !== undefined ? String(sb.levelFilter) : '';
  const schoolFilter = sb.schoolFilter || '';
  const sortBy = sb.sortBy || 'level-asc';
  const maxLimits = sb.maxPerLevel || { 0:3, 1:4, 2:3, 3:2, 4:2, 5:1, 6:1, 7:1, 8:1, 9:1 };

  let catalog = (sb.catalog || []).slice();

  if(query){
    catalog = catalog.filter(function(spell){ 
      return spell.name.toLowerCase().includes(query) || 
      (spell.desc && spell.desc.toLowerCase().includes(query)) ||
      (spell.quickEffect && spell.quickEffect.toLowerCase().includes(query)) ||
      (spell.damage && spell.damage.toLowerCase().includes(query)) ||
      (spell.tags && spell.tags.some(function(t){ return t.toLowerCase().includes(query); }));
    });
  }

  if(classFilter){
    catalog = catalog.filter(function(spell){ return (spell.classes || []).includes(classFilter); });
  }

  if(levelFilter !== ''){
    const targetLvl = parseInt(levelFilter, 10);
    catalog = catalog.filter(function(spell){ return (spell.levelNum !== undefined ? spell.levelNum : parseLevelNum(spell.levelText)) === targetLvl; });
  }

  if(schoolFilter){
    catalog = catalog.filter(function(spell){ return (spell.schoolName || spell.school) === schoolFilter; });
  }

  catalog.sort(function(a,b){
    const aLvl = a.levelNum !== undefined ? a.levelNum : parseLevelNum(a.levelText);
    const bLvl = b.levelNum !== undefined ? b.levelNum : parseLevelNum(b.levelText);
    if(sortBy === 'level-asc') return (aLvl - bLvl) || a.name.localeCompare(b.name);
    if(sortBy === 'level-desc') return (bLvl - aLvl) || a.name.localeCompare(b.name);
    if(sortBy === 'class'){
      const aClass = (a.classes && a.classes.length) ? a.classes.slice().sort()[0] : 'Universal';
      const bClass = (b.classes && b.classes.length) ? b.classes.slice().sort()[0] : 'Universal';
      return aClass.localeCompare(bClass) || (aLvl - bLvl) || a.name.localeCompare(b.name);
    }
    if(sortBy === 'school') return (a.schoolName||'').localeCompare(b.schoolName||'') || (aLvl - bLvl) || a.name.localeCompare(b.name);
    return a.name.localeCompare(b.name);
  });

  const rawList = sb.list || [];
  let list = rawList.slice();
  const effectiveQuery = (mySpellsFilterQuery || query).trim().toLowerCase();

  if(effectiveQuery){
    list = list.filter(function(spell){
      const catalogSpell = (sb.catalog || []).find(function(c){ return c.name === spell.name; });
      const fullDesc = catalogSpell ? (catalogSpell.desc || catalogSpell.quickEffect || '') : (spell.desc || '');
      const dmg = catalogSpell ? (catalogSpell.damage || '') : (spell.damage || '');
      return spell.name.toLowerCase().includes(effectiveQuery) ||
        fullDesc.toLowerCase().includes(effectiveQuery) ||
        dmg.toLowerCase().includes(effectiveQuery) ||
        (spell.tags && spell.tags.some(function(t){ return t.toLowerCase().includes(effectiveQuery); }));
    });
  }

  if(classFilter){
    list = list.filter(function(spell){
      const catalogSpell = (sb.catalog || []).find(function(c){ return c.name === spell.name; });
      const classes = (catalogSpell && catalogSpell.classes) ? catalogSpell.classes : (spell.classes || []);
      return classes.includes(classFilter);
    });
  }

  if(levelFilter !== ''){
    const targetLvl = parseInt(levelFilter, 10);
    list = list.filter(function(spell){
      const lvl = spell.levelNum !== undefined ? spell.levelNum : parseLevelNum(spell.levelText);
      return lvl === targetLvl;
    });
  }

  if(schoolFilter){
    list = list.filter(function(spell){
      const catalogSpell = (sb.catalog || []).find(function(c){ return c.name === spell.name; });
      const sch = catalogSpell ? (catalogSpell.schoolName || catalogSpell.school) : (spell.schoolName || spell.school);
      return sch === schoolFilter;
    });
  }

  list.sort(function(a,b){
    const aLvl = a.levelNum !== undefined ? a.levelNum : parseLevelNum(a.levelText);
    const bLvl = b.levelNum !== undefined ? b.levelNum : parseLevelNum(b.levelText);
    if(sortBy === 'level-asc') return (aLvl - bLvl) || a.name.localeCompare(b.name);
    if(sortBy === 'level-desc') return (bLvl - aLvl) || a.name.localeCompare(b.name);
    if(sortBy === 'class'){
      const aCat = (sb.catalog || []).find(function(c){ return c.name === a.name; });
      const bCat = (sb.catalog || []).find(function(c){ return c.name === b.name; });
      const aClasses = (aCat && aCat.classes) ? aCat.classes : (a.classes || []);
      const bClasses = (bCat && bCat.classes) ? bCat.classes : (b.classes || []);
      const aClass = aClasses.length ? aClasses.slice().sort()[0] : 'Universal';
      const bClass = bClasses.length ? bClasses.slice().sort()[0] : 'Universal';
      return aClass.localeCompare(bClass) || (aLvl - bLvl) || a.name.localeCompare(b.name);
    }
    if(sortBy === 'school'){
      const aCat = (sb.catalog || []).find(function(c){ return c.name === a.name; });
      const bCat = (sb.catalog || []).find(function(c){ return c.name === b.name; });
      const aSch = aCat ? (aCat.schoolName || aCat.school || '') : (a.schoolName || a.school || '');
      const bSch = bCat ? (bCat.schoolName || bCat.school || '') : (b.schoolName || b.school || '');
      return aSch.localeCompare(bSch) || (aLvl - bLvl) || a.name.localeCompare(b.name);
    }
    return a.name.localeCompare(b.name);
  });

  const catalogBox = document.getElementById('spell-catalog-list');
  const listBox = document.getElementById('spell-list');
  const statusBox = document.getElementById('spell-catalog-status');
  const errorBox = document.getElementById('spell-catalog-error');
  const listStatusBox = document.getElementById('spell-list-status');

  const countsPerLevel = {};
  for(let l=0; l<=9; l++) countsPerLevel[l] = 0;
  rawList.forEach(function(spell){
    const lvl = spell.levelNum !== undefined ? spell.levelNum : parseLevelNum(spell.levelText);
    countsPerLevel[lvl] = (countsPerLevel[lvl] || 0) + 1;
  });

  let levelSummary = [];
  for(let l=0; l<=9; l++){
    const maxVal = maxLimits[l] !== undefined ? maxLimits[l] : 0;
    if(maxVal > 0 || countsPerLevel[l] > 0){
      const label = l === 0 ? 'Cantrips' : 'Lvl ' + l;
      const isMax = countsPerLevel[l] >= maxVal && maxVal > 0;
      levelSummary.push((isMax ? '⚠️ ' : '') + label + ': ' + countsPerLevel[l] + '/' + maxVal);
    }
  }

  const hasFilter = query || mySpellsFilterQuery || classFilter || levelFilter !== '' || schoolFilter;
  const filterNotice = hasFilter ? ' (' + catalog.length + ' matched active filter)' : ' (574 total spells)';
  if(statusBox) statusBox.textContent = sb.loading ? 'Loading...' : catalog.length.toLocaleString() + ' shown' + filterNotice;
  const modalStatus = document.getElementById('spell-catalog-modal-status');
  if(modalStatus) modalStatus.textContent = sb.loading ? 'Loading...' : catalog.length.toLocaleString() + ' spells shown' + filterNotice;
  const footerCount = document.getElementById('spell-catalog-footer-count');
  if(footerCount) footerCount.textContent = (sb.catalog || []).length.toLocaleString() + ' total catalog spells · ' + catalog.length.toLocaleString() + ' filtered';
  if(errorBox) errorBox.innerHTML = sb.error ? '<div class="spell-empty">' + escapeHtml(sb.error) + '</div>' : '';

  if(listStatusBox){
    if(hasFilter && rawList.length > 0){
      listStatusBox.textContent = list.length + ' shown (' + rawList.length + ' total saved)' + (levelSummary.length ? ' · ' + levelSummary.join(' · ') : '');
    } else {
      listStatusBox.textContent = rawList.length + ' saved' + (levelSummary.length ? ' (' + levelSummary.join(' · ') + ')' : '');
    }
  }

  if(catalogBox){
    catalogBox.innerHTML = sb.loading ? '<div class="spell-empty">Loading spell catalog...</div>' : catalog.length ? catalog.map(function(spell){
      const inList = rawList.some(function(s){ return s.name === spell.name; });
      const classesStr = (spell.classes || []).slice(0, 4).join(', ');
      const classBadge = classesStr ? '<span class="badge" style="border-color:var(--danger-bright); color:var(--gold-bright); background:rgba(40,25,15,0.6);">🧙 ' + escapeHtml(classesStr) + '</span>' : '';
      const schoolBadge = spell.schoolName ? '<span class="badge school">' + escapeHtml(spell.schoolName) + '</span>' : '';
      const levelBadge = '<span class="badge level">' + escapeHtml(spell.levelText || 'Spell') + '</span>';
      const damageBadge = spell.damage ? '<span class="badge damage" style="border-color:var(--danger-bright); color:#ff6b6b; background:rgba(168,60,50,0.25); font-weight:600;">⚔️ ' + escapeHtml(spell.damage) + '</span>' : '';
      const descText = (spell.quickEffect && spell.quickEffect.length > 25 && !spell.quickEffect.includes('magical spell effect')) ? spell.quickEffect : (spell.desc || '');
      const escapedName = escapeJs(spell.name);
      return '<div class="spell-row">' +
        '<div class="spell-row-main">' +
          '<div class="spell-name">' + escapeHtml(spell.name) + '</div>' +
          '<div class="spell-meta">' + classBadge + ' ' + levelBadge + ' ' + schoolBadge + ' ' + damageBadge + (spell.source ? ' · ' + escapeHtml(spell.source) : '') + '</div>' +
          (descText ? '<div class="spell-desc-snippet" style="font-size:12px; color:var(--text-dim); margin-top:4px; line-height:1.4;">' + escapeHtml(descText) + '</div>' : '') +
        '</div>' +
        '<div class="spell-actions">' +
          '<button class="btn ghost small" title="View D&D Beyond style spell details" onclick="openSpellDetailModal(\'' + escapedName + '\')">👁️ View</button>' +
          '<button class="btn ghost small" onclick="toggleSpellFromCatalog(\'' + escapedName + '\')">' + (inList ? '✓ Added' : '+ Add') + '</button>' +
        '</div>' +
      '</div>';
    }).join('') : '<div class="spell-empty">No spells match the selected filters. <button class="btn ghost small" onclick="clearSpellFilters()">Clear Filters</button></div>';
  }

  if(listBox){
    if(rawList.length === 0){
      listBox.innerHTML = '<div class="spell-empty" style="padding:32px 20px; text-align:center; background:rgba(0,0,0,0.25); border:1px dashed var(--border-bright); border-radius:8px;">' +
        '<div style="font-size:36px; margin-bottom:8px;">✨</div>' +
        '<div style="font-size:16px; font-weight:bold; color:var(--gold-bright); font-family:Cinzel,serif;">Your Spellbook is Empty</div>' +
        '<div style="font-size:13px; color:var(--text-muted); max-width:480px; margin:8px auto 16px; line-height:1.4;">Browse over 1,200 D&D 5e spells from all classes, levels, and schools to add to your character\'s prepared list.</div>' +
        '<button class="btn" onclick="openSpellCatalogModal()" style="font-size:13px; font-weight:bold; padding:8px 18px; background:linear-gradient(180deg, var(--gold-bright), #8a641d); color:#000;">📜 + Browse & Add Spells (Full Catalog)</button>' +
      '</div>';
    } else if(list.length === 0){
      listBox.innerHTML = '<div class="spell-empty" style="padding:28px 20px; text-align:center; background:rgba(0,0,0,0.2); border:1px dashed var(--border); border-radius:8px;">' +
        '<div style="font-size:14px; color:var(--text-muted); margin-bottom:10px;">No saved spells match your active filters or search query.</div>' +
        '<button class="btn ghost small" onclick="clearSpellFilters()">🧹 Clear Filters</button>' +
      '</div>';
    } else {
      listBox.innerHTML = list.map(function(spell){
        const catalogSpell = (sb.catalog || []).find(function(c){ return c.name === spell.name; });
        const classesStr = catalogSpell && catalogSpell.classes ? catalogSpell.classes.slice(0, 4).join(', ') : '';
        const classBadge = classesStr ? '<span class="badge" style="border-color:var(--danger-bright); color:var(--gold-bright); background:rgba(40,25,15,0.6);">🧙 ' + escapeHtml(classesStr) + '</span>' : '';
        const schoolBadge = catalogSpell && catalogSpell.schoolName ? catalogSpell.schoolName : '';
        const levelBadge = '<span class="badge level">' + escapeHtml(spell.levelText || 'Added spell') + '</span>';
        const damageVal = catalogSpell && catalogSpell.damage ? catalogSpell.damage : (spell.damage || '');
        const damageBadge = damageVal ? '<span class="badge damage" style="border-color:var(--danger-bright); color:#ff6b6b; background:rgba(168,60,50,0.25); font-weight:600;">⚔️ ' + escapeHtml(damageVal) + '</span>' : '';
        const descText = catalogSpell ? ((catalogSpell.quickEffect && catalogSpell.quickEffect.length > 25 && !catalogSpell.quickEffect.includes('magical spell effect')) ? catalogSpell.quickEffect : catalogSpell.desc) : (spell.desc || '');
        const escapedName = escapeJs(spell.name);
        return '<div class="spell-list-item">' +
          '<div style="flex:1;">' +
            '<div class="spell-name">' + escapeHtml(spell.name) + '</div>' +
            '<div class="spell-meta">' + classBadge + ' ' + levelBadge + ' ' + (schoolBadge ? '<span class="badge school">' + escapeHtml(schoolBadge) + '</span>' : '') + ' ' + damageBadge + (spell.source ? ' · ' + escapeHtml(spell.source) : '') + '</div>' +
            (descText ? '<div class="spell-desc-snippet" style="font-size:12px; color:var(--text-dim); margin-top:4px; line-height:1.4;">' + escapeHtml(descText) + '</div>' : '') +
          '</div>' +
          '<div class="spell-actions">' +
            '<button class="btn ghost small" title="View D&D Beyond style spell details" onclick="openSpellDetailModal(\'' + escapedName + '\')">👁️ View</button>' +
            '<button class="btn ghost small" onclick="removeSpellFromList(\'' + escapedName + '\')">Remove</button>' +
          '</div>' +
        '</div>';
      }).join('');
    }
  }
}

function openSpellDetailModal(spellName){
  const catalog = state.spellbook.catalog || [];
  let spell = catalog.find(function(s){ return s.name === spellName; });
  if(!spell){
    const userSaved = (state.spellbook.list || []).find(function(s){ return s.name === spellName; });
    if(userSaved) spell = userSaved;
  }
  if(!spell) return;

  const classesText = (spell.classes && spell.classes.length) ? spell.classes.join(', ') : 'Universal';
  const sdClass = document.getElementById('sd-class');
  if(sdClass) sdClass.textContent = 'Class: ' + classesText;

  const sdName = document.getElementById('sd-name');
  if(sdName) sdName.textContent = spell.name;

  const subtitle = (spell.levelNum === 0 ? 'Cantrip' : spell.levelText || ('Level ' + spell.levelNum)) + ' ' + (spell.schoolName || spell.school || 'Enchantment');
  const sdSubtitle = document.getElementById('sd-subtitle');
  if(sdSubtitle) sdSubtitle.textContent = subtitle;

  const fullDescText = (spell.quickEffect && spell.quickEffect.length > 25 && !spell.quickEffect.includes('magical spell effect')) ? spell.quickEffect : ((spell.desc && spell.desc.length > 25 && !spell.desc.includes('magical spell effect')) ? spell.desc : 'You fill the area with magical spell effects according to the spell parameters.');
  const sdQuickEffect = document.getElementById('sd-quick-effect');
  if(sdQuickEffect) sdQuickEffect.textContent = fullDescText;

  const sdCasting = document.getElementById('sd-casting');
  if(sdCasting) sdCasting.textContent = spell.castingTime || '1 action';

  const sdRange = document.getElementById('sd-range');
  if(sdRange) sdRange.textContent = spell.range || 'Touch';

  const sdComponents = document.getElementById('sd-components');
  if(sdComponents) sdComponents.textContent = spell.components || 'V, S';

  const sdDuration = document.getElementById('sd-duration');
  if(sdDuration) sdDuration.textContent = spell.duration || 'Concentration, up to 1 minute';

  const sdDamage = document.getElementById('sd-damage');
  if(sdDamage){
    sdDamage.textContent = spell.damage ? ('⚔️ ' + spell.damage) : '—';
  }

  const sdSource = document.getElementById('sd-source');
  if(sdSource) sdSource.textContent = spell.source || "Player's Handbook (2014)";

  const sdDesc = document.getElementById('sd-desc');
  if(sdDesc) sdDesc.innerHTML = '<p>' + escapeHtml(fullDescText).replace(/\n/g, '</p><p>') + '</p>';

  const sdHigherText = document.getElementById('sd-higher-text');
  if(sdHigherText) sdHigherText.textContent = spell.higherLevels || 'No higher level benefit.';

  const tagsList = document.getElementById('sd-tags-list');
  if(tagsList){
    const tags = (spell.damage ? ['DAMAGE'] : []).concat(spell.tags || ['UTILITY']);
    const uniqueTags = Array.from(new Set(tags));
    tagsList.innerHTML = uniqueTags.map(function(t){ return '<span class="tag-chip">' + escapeHtml(t) + '</span>'; }).join('');
  }

  const inList = (state.spellbook.list || []).some(function(s){ return s.name === spell.name; });
  const actionBtn = document.getElementById('sd-action-btn');
  if(actionBtn){
    actionBtn.textContent = inList ? 'Remove from My Spell List' : '+ Add to My Spell List';
    actionBtn.onclick = function(){
      toggleSpellFromCatalog(spell.name);
      openSpellDetailModal(spell.name);
    };
  }

  const sdOverlay = document.getElementById('spell-detail-overlay');
  if(sdOverlay) sdOverlay.classList.add('open');
}

function closeSpellDetailModal(){
  const sdOverlay = document.getElementById('spell-detail-overlay');
  if(sdOverlay) sdOverlay.classList.remove('open');
}

function openMaxSpellsModal(){
  const grid = document.getElementById('max-spells-inputs-grid');
  if(!grid) return;
  const maxLimits = state.spellbook.maxPerLevel || { 0:3, 1:4, 2:3, 3:2, 4:2, 5:1, 6:1, 7:1, 8:1, 9:1 };
  let html = '';
  for(let lvl=0; lvl<=9; lvl++){
    const label = lvl === 0 ? 'Cantrips (Level 0)' : ('Level ' + lvl + ' Spells');
    const val = maxLimits[lvl] !== undefined ? maxLimits[lvl] : 0;
    html += '<div class="form-row">' +
        '<label>' + label + '</label>' +
        '<input type="number" id="m-lvl-' + lvl + '" value="' + val + '" min="0" max="20">' +
      '</div>';
  }
  grid.innerHTML = html;
  const overlay = document.getElementById('max-spells-overlay');
  if(overlay) overlay.classList.add('open');
}

function closeMaxSpellsModal(){
  const overlay = document.getElementById('max-spells-overlay');
  if(overlay) overlay.classList.remove('open');
}

function saveMaxSpellsSettings(){
  state.spellbook.maxPerLevel = state.spellbook.maxPerLevel || {};
  for(let lvl=0; lvl<=9; lvl++){
    const input = document.getElementById('m-lvl-' + lvl);
    if(input){
      state.spellbook.maxPerLevel[lvl] = Math.max(0, parseInt(input.value, 10) || 0);
    }
  }
  save();
  closeMaxSpellsModal();
  renderSpellbookMenu();
}

function escapeJs(text){
  return String(text || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\n/g, ' ');
}

function escapeHtml(s){
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

async function refreshSpellCatalog(){
  if(state.spellbook.loading) return;
  state.spellbook.loading = true;
  state.spellbook.error = '';
  renderSpellbookMenu();
  try{
    let rawCatalog = null;
    if(Array.isArray(window.SPELL_CATALOG) && window.SPELL_CATALOG.length > 0){
      rawCatalog = window.SPELL_CATALOG;
    } else {
      const tag = document.getElementById('spell-catalog-data');
      if(tag && tag.textContent.trim()){
        try {
          let text = tag.textContent.trim();
          if(text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
          rawCatalog = JSON.parse(text);
        } catch(e){}
      }
    }
    
    if(!rawCatalog){
      try {
        const localResponse = await fetch('spell-catalog.json', { cache: 'no-store' });
        if(localResponse.ok){
          let text = await localResponse.text();
          if(text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
          rawCatalog = JSON.parse(text);
        }
      } catch(e){}
    }

    if(rawCatalog && Array.isArray(rawCatalog)){
      const SCHOOL_MAP = {
        'A': 'Abjuration',
        'C': 'Conjuration',
        'D': 'Divination',
        'E': 'Enchantment',
        'I': 'Illusion',
        'N': 'Necromancy',
        'T': 'Transmutation',
        'V': 'Evocation'
      };
      const mapByName = new Map();
      const merged = [];
      rawCatalog.forEach(function(spell){
        const name = String(spell?.name || '').trim();
        if(!name) return;
        const key = name.toLowerCase();
        const schoolName = (spell.schoolName && spell.schoolName !== 'Universal') ? spell.schoolName : (SCHOOL_MAP[spell.school] || spell.schoolName || 'Universal');
        const bestDesc = (spell.quickEffect && spell.quickEffect.length > 25 && !spell.quickEffect.includes('magical spell effect')) ? spell.quickEffect : ((spell.desc && spell.desc.length > 25 && !spell.desc.includes('magical spell effect')) ? spell.desc : '');
        if(!mapByName.has(key)){
          const spellCopy = {
            name: spell.name,
            levelNum: spell.levelNum !== undefined ? spell.levelNum : (spell.levelText === 'Cantrip' ? 0 : (parseInt((spell.levelText||'').replace(/\D/g,''),10)||0)),
            levelText: spell.levelText || 'Spell',
            source: spell.source || 'PHB',
            school: spell.school || '',
            schoolName: schoolName,
            classes: Array.isArray(spell.classes) ? [...spell.classes] : [],
            castingTime: spell.castingTime || '1 action',
            range: spell.range || '60 feet',
            components: spell.components || 'V, S',
            duration: spell.duration || 'Instantaneous',
            quickEffect: bestDesc,
            desc: bestDesc,
            higherLevels: spell.higherLevels || '',
            tags: Array.isArray(spell.tags) ? [...spell.tags] : [],
            damage: spell.damage || ''
          };
          mapByName.set(key, spellCopy);
          merged.push(spellCopy);
        } else {
          const existing = mapByName.get(key);
          if(Array.isArray(spell.classes)){
            spell.classes.forEach(function(c){ if(!existing.classes.includes(c)) existing.classes.push(c); });
          }
          if(Array.isArray(spell.tags)){
            spell.tags.forEach(function(t){ if(!existing.tags.includes(t)) existing.tags.push(t); });
          }
          if(!existing.damage && spell.damage) existing.damage = spell.damage;
          if((!existing.desc || existing.desc.length < 25 || existing.desc.includes('magical spell effect')) && bestDesc && bestDesc.length > 25 && !bestDesc.includes('magical spell effect')) {
            existing.desc = bestDesc;
            existing.quickEffect = bestDesc;
          }
          if(schoolName && schoolName !== 'Universal') existing.schoolName = schoolName;
        }
      });
      merged.sort(function(a,b){ return (a.levelNum - b.levelNum) || String(a.name || '').localeCompare(String(b.name || '')); });
      
      state.spellbook.catalog = merged;
      state.spellbook.catalogLoaded = true;

      if(Array.isArray(state.spellbook.list)){
        state.spellbook.list.forEach(function(s){
          const cat = mapByName.get(s.name.toLowerCase());
          if(cat){
            s.damage = cat.damage || s.damage || '';
            s.desc = cat.desc || s.desc || '';
            s.classes = cat.classes || s.classes || [];
            s.schoolName = cat.schoolName || s.schoolName || '';
          }
        });
      }

      save();
      renderSpellbookMenu();
    } else {
      throw new Error('Spell catalog could not be loaded.');
    }
  } catch (error) {
    console.error(error);
    state.spellbook.error = 'Could not load spell catalog.';
  } finally {
    state.spellbook.loading = false;
    renderSpellbookMenu();
  }
}

async function toggleSpellFromCatalog(name){
  const existingIndex = state.spellbook.list.findIndex(function(spell){ return spell.name === name; });
  if(existingIndex >= 0){
    state.spellbook.list.splice(existingIndex, 1);
    save();
    renderSpellbookMenu();
    return;
  }
  const catalogSpell = state.spellbook.catalog.find(function(spell){ return spell.name === name; });
  if(!catalogSpell){
    return;
  }

  const spellLevel = catalogSpell.levelNum !== undefined ? catalogSpell.levelNum : parseLevelNum(catalogSpell.levelText);
  const maxLimits = state.spellbook.maxPerLevel || { 0:3, 1:4, 2:3, 3:2, 4:2, 5:1, 6:1, 7:1, 8:1, 9:1 };
  const maxAllowed = maxLimits[spellLevel] !== undefined ? maxLimits[spellLevel] : 99;

  const currentCount = state.spellbook.list.filter(function(s){
    const l = s.levelNum !== undefined ? s.levelNum : parseLevelNum(s.levelText);
    return l === spellLevel;
  }).length;

  if(maxAllowed > 0 && currentCount >= maxAllowed){
    const lvlName = spellLevel === 0 ? 'Cantrips' : ('Level ' + spellLevel);
    alert('Limit Reached! You already have ' + currentCount + '/' + maxAllowed + ' ' + lvlName + ' in My Spell List.\n\nRemove a spell or click "⚙️ Max Spells Limits" to increase your limit.');
    return;
  }

  state.spellbook.list.push({
    name: catalogSpell.name,
    levelNum: spellLevel,
    levelText: catalogSpell.levelText || 'Spell',
    source: catalogSpell.source,
    school: catalogSpell.school || '',
    schoolName: catalogSpell.schoolName || '',
    classes: catalogSpell.classes || [],
    damage: catalogSpell.damage || '',
    desc: catalogSpell.desc || catalogSpell.quickEffect || ''
  });
  save();
  renderSpellbookMenu();
}

function removeSpellFromList(name){
  state.spellbook.list = state.spellbook.list.filter(function(spell){ return spell.name !== name; });
  save();
  renderSpellbookMenu();
}

function toggleSpellbookMenu(){
  state.spellbook.open = !state.spellbook.open;
  save();
  renderSpellbookMenu();
}

function toggleAttunementMenu(){
  state.attunements.open = !state.attunements.open;
  save();
  renderAttunementMenu();
}

function pickAttunementItem(slotIndex){
  const used = new Set(state.attunements.slots.filter(Boolean));
  const candidates = state.items.filter(i=>i.attunementRequired && !used.has(i.id));
  if(candidates.length===0){
    alert('No unattuned items require attunement.');
    return;
  }
  if(candidates.length===1){
    state.attunements.slots[slotIndex] = candidates[0].id;
    save();
    renderAll();
    return;
  }
  const names = candidates.map(function(c,idx){ return (idx+1) + '. ' + c.name; }).join('\n');
  const pick = prompt('Choose an item to attune to slot ' + (slotIndex + 1) + ':\n' + names);
  const idx = parseInt(pick,10)-1;
  if(candidates[idx]){
    state.attunements.slots[slotIndex] = candidates[idx].id;
    save();
    renderAll();
  }
}

function clearAttunementSlot(slotIndex){
  state.attunements.slots[slotIndex] = null;
  save();
  renderAll();
}

function resetAttunements(){
  state.attunements.slots = [null,null,null];
  save();
  renderAll();
}

function toggleAttunementForItem(id){
  const item = state.items.find(i=>i.id===id);
  if(!item || !item.attunementRequired) return;
  const currentIndex = attunedSlotIndex(id);
  if(currentIndex >= 0){
    clearAttunementSlot(currentIndex);
    return;
  }
  const openIndex = state.attunements.slots.findIndex(slot=>!slot);
  if(openIndex === -1){
    alert('You only have 3 attunement slots. Remove one first.');
    return;
  }
  state.attunements.slots[openIndex] = id;
  save();
  renderAll();
}

function toggleDeathSaveMenu(){
  state.deathSaves.open = !state.deathSaves.open;
  save();
  renderDeathSaves();
}

function toggleDeathSave(kind, idx){
  const list = kind === 'success' ? state.deathSaves.successes : state.deathSaves.failures;
  list[idx] = !list[idx];
  save();
  renderDeathSaves();
}

function resetDeathSaves(){
  state.deathSaves.successes = [false,false,false];
  state.deathSaves.failures = [false,false,false];
  save();
  renderDeathSaves();
}

function renderGrid(){
  const grid = document.getElementById('item-grid');
  if(!grid) return;

  const searchEl = document.getElementById('search-input');
  const typeEl = document.getElementById('filter-type');
  const rarityEl = document.getElementById('filter-rarity');
  const sortEl = document.getElementById('sort-by');

  const q = (searchEl && searchEl.value ? searchEl.value : '').toLowerCase();
  const typeF = typeEl && typeEl.value ? typeEl.value : '';
  const rarityF = rarityEl && rarityEl.value ? rarityEl.value : '';
  const sortBy = sortEl && sortEl.value ? sortEl.value : 'name';
  const rarityOrder = ['Common','Uncommon','Rare','Very Rare','Legendary','Artifact'];

  let items = (state.items||[]).filter(i=>{
    if(q && !i.name.toLowerCase().includes(q) && !(i.desc||'').toLowerCase().includes(q)) return false;
    if(typeF && i.type!==typeF) return false;
    if(rarityF && i.rarity!==rarityF) return false;
    return true;
  });

  items.sort((a,b)=>{
    if(sortBy==='rarity') return rarityOrder.indexOf(b.rarity)-rarityOrder.indexOf(a.rarity);
    if(sortBy==='weight') return (b.weight||0)-(a.weight||0);
    if(sortBy==='type') return a.type.localeCompare(b.type);
    return a.name.localeCompare(b.name);
  });

  grid.innerHTML = '';
  grid.ondragover = e=>{
    const dragged = (state.items||[]).find(i=>i.id===draggingItemId);
    if(dragged && dragged.equipped){
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      grid.classList.add('drag-over-unequip');
    }
  };
  grid.ondragleave = e=>{ if(e.target===grid) grid.classList.remove('drag-over-unequip'); };
  grid.ondrop = e=>{
    e.preventDefault();
    grid.classList.remove('drag-over-unequip');
    const id = e.dataTransfer.getData('text/plain');
    const item = (state.items||[]).find(i=>i.id===id);
    if(item && item.equipped){
      item.equipped = false;
      save(); renderAll();
    }
  };
  if(items.length===0){
    grid.innerHTML = '<div class="empty-state">No items match. Add loot with "+ Add Item".</div>';
    return;
  }
  items.forEach(i=>{
    const card = document.createElement('div');
    card.className = 'item-card' + (i.id===state.selectedId ? ' selected' : '');
    card.dataset.rarity = i.rarity;
    card.innerHTML = (i.equipped ? '<span class="equipped-badge">●</span>' : '') +
      '<span class="icon">' + (i.icon || '❔') + '</span>' +
      '<span class="name-strip">' + escapeHtml(i.name) + '</span>' +
      (i.qty>1 ? '<span class="qty">x' + i.qty + '</span>' : '');
    card.onclick = ()=>{ state.selectedId = i.id; save(); renderGrid(); renderDetail(); };
    card.draggable = !!i.slot;
    if(i.slot){
      card.ondragstart = e=>{ draggingItemId = i.id; e.dataTransfer.setData('text/plain', i.id); e.dataTransfer.effectAllowed='move'; card.classList.add('dragging'); };
      card.ondragend = ()=>{ card.classList.remove('dragging'); draggingItemId = null; };
    }
    grid.appendChild(card);
  });
}

function renderDetail(){
  const panel = document.getElementById('detail-panel');
  if(!panel) return;
  const item = (state.items||[]).find(i=>i.id===state.selectedId);
  if(!item){
    panel.innerHTML = '<div class="detail-empty">Select an item to inspect it.</div>';
    return;
  }
  const buffsHtml = (item.buffs||[]).map(b=>
    '<div class="effect-tag"><span>▲</span><span><b>' + escapeHtml(b.name) + '</b>' + (b.desc? ' — '+escapeHtml(b.desc):'') + '</span></div>'
  ).join('');
  const debuffsHtml = (item.debuffs||[]).map(d=>
    '<div class="effect-tag debuff"><span>▼</span><span><b>' + escapeHtml(d.name) + '</b>' + (d.desc? ' — '+escapeHtml(d.desc):'') + '</span></div>'
  ).join('');
  panel.innerHTML = '<div class="detail-header">' +
      '<div class="detail-icon">' + (item.icon||'❔') + '</div>' +
      '<div>' +
        '<div class="detail-name">' + escapeHtml(item.name) + '</div>' +
        '<div class="detail-meta"><span class="rarity-tag" data-r="' + item.rarity + '" style="color:' + rarityColor(item.rarity) + '">' + item.rarity + '</span> · ' + item.type + (item.slot? ' · '+SLOT_LABELS[item.slot]:'') + '</div>' +
      (item.type === 'Weapon' ? (
        isProficientWithWeapon(item)
          ? '<div style="margin-top:6px; display:inline-flex; align-items:center; gap:4px; background:rgba(34,197,94,0.15); border:1px solid #22c55e; color:#4ade80; padding:3px 8px; border-radius:4px; font-size:11px; font-weight:bold;">✨ Proficient (+' + (state.characterStats ? (state.characterStats.prof || 2) : 2) + ' Atk) [' + (item.proficiencyType || 'Simple') + ']</div>'
          : '<div style="margin-top:6px; display:inline-flex; align-items:center; gap:4px; background:rgba(239,68,68,0.15); border:1px solid #ef4444; color:#f87171; padding:3px 8px; border-radius:4px; font-size:11px; font-weight:bold;">⚠️ Not Proficient [' + (item.proficiencyType || 'Simple') + ']</div>'
      ) : '') +
      '</div>' +
    '</div>' +
    (item.desc ? '<div class="detail-desc">"' + escapeHtml(item.desc) + '"</div>' : '') +
    '<div class="detail-stats">' +
      '<span>⚖ ' + (item.weight||0) + ' lb</span>' +
      '<span>× ' + (item.qty||1) + '</span>' +
      (item.equipped ? '<span style="color:var(--gold-bright)">● Equipped</span>' : '') +
      (item.attunementRequired ? '<span style="color:var(--gold-bright)">' + (attunedSlotIndex(item.id) >= 0 ? '● Attuned' : 'Requires Attunement') + '</span>' : '') +
    '</div>' +
    '<div class="buff-list">' + buffsHtml + debuffsHtml + '</div>' +
    '<div class="detail-actions">' +
      (item.slot ? '<button class="btn small" onclick="toggleEquip(\'' + item.id + '\')">' + (item.equipped?'Unequip':'Equip') + '</button>' : '') +
      (item.attunementRequired ? '<button class="btn small" onclick="toggleAttunementForItem(\'' + item.id + '\')">' + (attunedSlotIndex(item.id) >= 0 ? 'Remove Attunement' : 'Attune') + '</button>' : '') +
      '<button class="btn ghost small" onclick="editItem(\'' + item.id + '\')">Edit</button>' +
      '<button class="btn ghost small" onclick="adjustQty(\'' + item.id + '\', 1)">+1</button>' +
      '<button class="btn ghost small" onclick="adjustQty(\'' + item.id + '\', -1)">−1</button>' +
      '<button class="btn danger small" onclick="deleteItem(\'' + item.id + '\')">Delete</button>' +
    '</div>';
}

function rarityColor(r){
  return {
    'Common':'var(--common)','Uncommon':'var(--uncommon)','Rare':'var(--rare)',
    'Very Rare':'var(--veryrare)','Legendary':'var(--legendary)','Artifact':'var(--artifact)'
  }[r] || 'var(--text)';
}

function toggleEquip(id){
  const item = (state.items||[]).find(i=>i.id===id);
  if(!item) return;
  if(!item.equipped){
    state.items.forEach(i=>{ if(i.slot===item.slot && i.id!==item.id) i.equipped=false; });
    item.equipped = true;
  } else {
    item.equipped = false;
  }
  save(); renderAll();
}

function adjustQty(id, delta){
  const item = (state.items||[]).find(i=>i.id===id);
  if(!item) return;
  item.qty = Math.max(1, (item.qty||1)+delta);
  save(); renderAll();
}

function deleteItem(id){
  if(!confirm('Delete this item from the hoard?')) return;
  state.items = (state.items||[]).filter(i=>i.id!==id);
  if(state.selectedId===id) state.selectedId=null;
  if(state.attunements && state.attunements.slots){
    state.attunements.slots = state.attunements.slots.map(slot=>slot===id ? null : slot);
  }
  save(); renderAll();
}

function setItemIcon(emoji){
  const iconInput = document.getElementById('f-icon');
  if(iconInput){
    iconInput.value = emoji;
    iconInput.focus();
  }
}

let currentTab = 'buffs';
let tempBuffs = [];
let tempDebuffs = [];


function toggleProfTypeRow(){
  const typeVal = document.getElementById('f-type') ? document.getElementById('f-type').value : '';
  const row = document.getElementById('f-prof-type-row');
  if(row) row.style.display = (typeVal === 'Weapon') ? 'block' : 'none';
}
function isProficientWithWeapon(item){
  if(!item || item.type !== 'Weapon') return true;
  const cs = state.characterStats || {};
  const pType = item.proficiencyType || 'Simple';
  if(pType === 'None') return true;
  if(cs.profSimple && pType === 'Simple') return true;
  if(cs.profMartial && pType === 'Martial') return true;
  if(cs.profExotic && pType === 'Exotic') return true;
  const notes = (cs.weapons || '').toLowerCase();
  if(notes.includes(pType.toLowerCase())) return true;
  if(item.name && notes.includes(item.name.toLowerCase())) return true;
  return false;
}

function openItemModal(){
  document.getElementById('modal-title').textContent = 'Add Item';
  document.getElementById('edit-id').value = '';
  document.getElementById('f-name').value = '';
  document.getElementById('f-icon').value = '';
  document.getElementById('f-type').value = 'Weapon';
  if(document.getElementById('f-prof-type')) document.getElementById('f-prof-type').value = 'Simple';
  toggleProfTypeRow();
  document.getElementById('f-rarity').value = 'Common';
  document.getElementById('f-slot').value = '';
  document.getElementById('f-weight').value = 0;
  document.getElementById('f-qty').value = 1;
  document.getElementById('f-attunement').checked = false;
  document.getElementById('f-desc').value = '';
  tempBuffs = [];
  tempDebuffs = [];
  switchTab('buffs');
  renderEffectRows();
  document.getElementById('item-overlay').classList.add('open');
}

function editItem(id){
  const item = (state.items||[]).find(i=>i.id===id);
  if(!item) return;
  document.getElementById('modal-title').textContent = 'Edit Item';
  document.getElementById('edit-id').value = item.id;
  document.getElementById('f-name').value = item.name;
  document.getElementById('f-icon').value = item.icon||'';
  document.getElementById('f-type').value = item.type;
  if(document.getElementById('f-prof-type')) document.getElementById('f-prof-type').value = item.proficiencyType || 'Simple';
  toggleProfTypeRow();
  document.getElementById('f-rarity').value = item.rarity;
  document.getElementById('f-slot').value = item.slot||'';
  document.getElementById('f-weight').value = item.weight||0;
  document.getElementById('f-qty').value = item.qty||1;
  document.getElementById('f-attunement').checked = !!item.attunementRequired;
  document.getElementById('f-desc').value = item.desc||'';
  tempBuffs = JSON.parse(JSON.stringify(item.buffs||[]));
  tempDebuffs = JSON.parse(JSON.stringify(item.debuffs||[]));
  switchTab('buffs');
  renderEffectRows();
  document.getElementById('item-overlay').classList.add('open');
}

function closeItemModal(){
  const itemOverlay = document.getElementById('item-overlay');
  if(itemOverlay) itemOverlay.classList.remove('open');
}

function switchTab(tab){
  currentTab = tab;
  const tabBuffs = document.getElementById('tab-buffs');
  if(tabBuffs) tabBuffs.classList.toggle('active', tab==='buffs');
  
  const tabDebuffs = document.getElementById('tab-debuffs');
  if(tabDebuffs) tabDebuffs.classList.toggle('active', tab==='debuffs');

  const buffsEd = document.getElementById('buffs-editor');
  if(buffsEd) buffsEd.style.display = tab==='buffs' ? 'block' : 'none';

  const debuffsEd = document.getElementById('debuffs-editor');
  if(debuffsEd) debuffsEd.style.display = tab==='debuffs' ? 'block' : 'none';
}

function renderEffectRows(){
  const buffsBox = document.getElementById('buffs-rows');
  const debuffsBox = document.getElementById('debuffs-rows');
  if(buffsBox){
    buffsBox.innerHTML = tempBuffs.map((b,idx)=>'<div class="effect-row"><input type="text" placeholder="Name" value="' + escapeHtml(b.name) + '" oninput="tempBuffs[' + idx + '].name=this.value"><input type="text" placeholder="Description" value="' + escapeHtml(b.desc||'') + '" oninput="tempBuffs[' + idx + '].desc=this.value"><button class="remove-x" onclick="removeEffectRow(\'buffs\',' + idx + ')">✕</button></div>').join('');
  }
  if(debuffsBox){
    debuffsBox.innerHTML = tempDebuffs.map((b,idx)=>'<div class="effect-row"><input type="text" placeholder="Name" value="' + escapeHtml(b.name) + '" oninput="tempDebuffs[' + idx + '].name=this.value"><input type="text" placeholder="Description" value="' + escapeHtml(b.desc||'') + '" oninput="tempDebuffs[' + idx + '].desc=this.value"><button class="remove-x" onclick="removeEffectRow(\'debuffs\',' + idx + ')">✕</button></div>').join('');
  }
}

function addEffectRow(kind){
  if(kind==='buffs') tempBuffs.push({name:'',desc:''});
  else tempDebuffs.push({name:'',desc:''});
  renderEffectRows();
}
function removeEffectRow(kind, idx){
  if(kind==='buffs') tempBuffs.splice(idx,1);
  else tempDebuffs.splice(idx,1);
  renderEffectRows();
}

function saveItem(){
  const nameInput = document.getElementById('f-name');
  const name = nameInput ? nameInput.value.trim() : '';
  if(!name){ alert('Give the item a name.'); return; }
  const editId = document.getElementById('edit-id').value;
  const attunementRequired = document.getElementById('f-attunement').checked;
  const data = {
    name,
    icon: document.getElementById('f-icon').value.trim() || '❔',
    type: document.getElementById('f-type').value,
    rarity: document.getElementById('f-rarity').value,
    slot: document.getElementById('f-slot').value || null,
    weight: parseFloat(document.getElementById('f-weight').value) || 0,
    qty: parseInt(document.getElementById('f-qty').value) || 1,
    desc: document.getElementById('f-desc').value.trim(),
    attunementRequired,
    proficiencyType: (document.getElementById('f-type').value==='Weapon') ? (document.getElementById('f-prof-type') ? document.getElementById('f-prof-type').value : 'Simple') : null,
    buffs: tempBuffs.filter(b=>b.name.trim()),
    debuffs: tempDebuffs.filter(b=>b.name.trim()),
  };
  if(editId){
    const item = (state.items||[]).find(i=>i.id===editId);
    if(item){
      Object.assign(item, data);
      if(!data.slot) item.equipped = false;
    }
  } else {
    state.items = state.items || [];
    state.items.push(Object.assign({id:uid(), equipped:false}, data));
  }
  if(!attunementRequired && state.attunements && state.attunements.slots){
    state.attunements.slots = state.attunements.slots.map(slot=>slot===editId ? null : slot);
  }
  save();
  closeItemModal();
  renderAll();
}

function openSettings(){
  document.getElementById('s-campaign').value = state.campaign || '';
  const currency = state.currency || { platinum:0, gold:0, electrum:0, silver:0, copper:0 };
  document.getElementById('s-platinum').value = currency.platinum || 0;
  document.getElementById('s-gold').value = currency.gold || 0;
  document.getElementById('s-electrum').value = currency.electrum || 0;
  document.getElementById('s-silver').value = currency.silver || 0;
  document.getElementById('s-copper').value = currency.copper || 0;
  document.getElementById('s-capacity').value = state.capacity || 150;
  renderThemeSwatches();
  document.getElementById('settings-overlay').classList.add('open');
}
function saveSettings(){
  state.campaign = document.getElementById('s-campaign').value.trim();
  state.currency = {
    platinum: parseInt(document.getElementById('s-platinum').value, 10) || 0,
    gold: parseInt(document.getElementById('s-gold').value, 10) || 0,
    electrum: parseInt(document.getElementById('s-electrum').value, 10) || 0,
    silver: parseInt(document.getElementById('s-silver').value, 10) || 0,
    copper: parseInt(document.getElementById('s-copper').value, 10) || 0,
  };
  state.capacity = parseFloat(document.getElementById('s-capacity').value) || 150;
  save();
  document.getElementById('settings-overlay').classList.remove('open');
  renderAll();
}
function resetAll(){
  state = { campaign:'Party Loot', currency:{ platinum:0, gold:0, electrum:0, silver:0, copper:0 }, capacity:150, items:[], selectedId:null,
    deathSaves:{ open:true, successes:[false,false,false], failures:[false,false,false] },
    attunements:{ open:true, slots:[null,null,null] },
    spellSlots:{ max:{ 1:4, 2:3, 3:2, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0 }, used:{ 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0 } },
    spellbook:{ open:true, query:'', levelFilter:'', schoolFilter:'', sortBy:'level-asc', catalogLoaded:false, loading:false, error:'', catalog:[], list:[], maxPerLevel:{ 0:3, 1:4, 2:3, 3:2, 4:2, 5:1, 6:1, 7:1, 8:1, 9:1 } },
    theme:{ preset:'leather', customBg:'#100b08', customAccent:'#c9a227' } };
  save();
  applyTheme();
  document.getElementById('settings-overlay').classList.remove('open');
  renderAll();
}
function exportData(){
  const blob = new Blob([JSON.stringify(state,null,2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = (state.campaign||'hoard').replace(/\s+/g,'_') + '_inventory.json';
  a.click();
  URL.revokeObjectURL(url);
}
function importData(evt){
  const file = evt.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e=>{
    try{
      const data = JSON.parse(e.target.result);
      state = Object.assign({campaign:'Party Loot', currency:{ platinum:0, gold:0, electrum:0, silver:0, copper:0 }, capacity:150, items:[], selectedId:null,
        deathSaves:{ open:true, successes:[false,false,false], failures:[false,false,false] },
        attunements:{ open:true, slots:[null,null,null] },
        spellSlots:{ max:{ 1:4, 2:3, 3:2, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0 }, used:{ 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0, 8:0, 9:0 } },
        spellbook:{ open:true, query:'', levelFilter:'', schoolFilter:'', sortBy:'level-asc', catalogLoaded:false, loading:false, error:'', catalog:[], list:[], maxPerLevel:{ 0:3, 1:4, 2:3, 3:2, 4:2, 5:1, 6:1, 7:1, 8:1, 9:1 } },
        theme:{ preset:'leather', customBg:'#100b08', customAccent:'#c9a227' }}, data);
      normalizeState();
      save();
      applyTheme();
      renderAll();
      document.getElementById('settings-overlay').classList.remove('open');
    }catch(err){ alert('Could not read that file — is it valid JSON exported from Hoard?'); }
  };
  reader.readAsText(file);
}

document.querySelectorAll('.overlay').forEach(ov=>{
  ov.addEventListener('click', e=>{ if(e.target===ov) ov.classList.remove('open'); });
});

try {
  load();
  normalizeState();
  applyTheme();
  renderAll();
  refreshSpellCatalog();
} catch(err) {
  console.error("Startup error:", err);
}
